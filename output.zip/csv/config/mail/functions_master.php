<?php

function companylogoexist($a) {
    $getlogo = mysql_fetch_array(mysql_query("SELECT `logo` FROM `settings` WHERE `cus_id`='" . $a . "'"));
    if ($getlogo['logo'] != '') {
        $res = '1';
    } else {
        $res = '0';
    }
    return $res;
}
function fuseremailverify($a,$b){
  $num = '';
        for ($i = 0; $i < 6; $i++)
            $num .= mt_rand(0, 9);
        $otp = $num;
         $fselnocheck =DB_QUERY("SELECT * FROM `customer` WHERE `emailid`='".$a."'");
        if($fselnocheck['cusid']=='')
        {
        $fsel = DB_QUERY("SELECT * FROM  `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
        $resa=mysql_query("UPDATE `customer` SET `otp`='".$otp."',`emailid`='".$a."' WHERE `cusid`='".$_SESSION['FUID']."'");
        //$resa->execute(array($otp,$a,$_SESSION['FUID']));
         verificationmailprofile($a, $otp, $_SESSION['FUID']);
        header("location:" . WEB_ROOT . "signup/emailverify/");
        exit;
        }
        else{
              $res = '<div class="alert alert-danger alert-dismissible"><i class="icon fa fa-close"></i> Already Registered Emailid.</div>';
        }
        return $res;
}
function fuserphonenoverify($a,$b){
  $num = '';
        for ($i = 0; $i < 6; $i++)
            $num .= mt_rand(0, 9);
        $otp = $num;
        $fselnocheck =DB_QUERY("SELECT * FROM `customer` WHERE `phoneno`='".$a."'");
        if($fselnocheck['cusid']=='')
        {
        $fsel = DB_QUERY("SELECT * FROM  `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
        $resa=mysql_query("UPDATE `customer` SET `otp`='".$otp."',`phoneno`='".$a."' WHERE `cusid`='".$_SESSION['FUID']."'");
        //$resa->execute(array($otp,$a,$_SESSION['FUID']));
        $message = 'Hi ' . $fsel['firstname'] . ', Your one time verification code for NBAYSMART is ' . $otp . '. Thank you';
        sendsms('NBAYSI', $message, $a, $b, '1');
        header("location:" . WEB_ROOT . "signup/phoneverify/");
        exit;
        }
        else{
            $res = '<div class="alert alert-danger alert-dismissible"><i class="icon fa fa-close"></i> Already Registered Mobile Number.</div>';
        }
        return $res;
}
function phoneotpverify($a,$b){
  
   if ($a != '') {
        $ress = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='".$_SESSION['FUID']."'");
//        $ress2->execute(array($_SESSION['FUID']));
//        $ress=$ress2->fetch(PDO::FETCH_ASSOC);
        if ($a == $ress['otp']) {
            $resa =DB("UPDATE `customer` SET `phonenoverification`='1' WHERE `cusid`='".$_SESSION['FUID']."'");
                //$resa->execute(array(1,$_SESSION['FUID']));
                header("location:" . WEB_ROOT . "editprofile/");
        }  
        else{
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i>Please Enter Correct OTP</h4></div>';
        }
}
 return $res;
}
function emailotpverify($a,$b){
    
   if ($a != '') {
        $ress = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='".$_SESSION['FUID']."'");
        if ($a == $ress['otp']) {
            $resa = DB("UPDATE `customer` SET `emailverification`='1' WHERE `cusid`='".$_SESSION['FUID']."'");
                //$resa->execute(array(1,$_SESSION['FUID']));
                header("location:" . WEB_ROOT . "editprofile/");
        }  
        else{
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i>Please Enter Correct OTP</h4></div>';
        }
}
 return $res;
}

function addcategory($a, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k, $l, $m, $q, $n, $o, $p) {
    if ($p == '') {
        $ress = DB_QUERY("SELECT `cid` FROM `category` WHERE (`categoryname`='" . trim($c) . "' OR `link`='" . trim($d) . "') AND `status`!='2'");

        if ($ress['cid'] == '') {
            $resa = mysql_query("INSERT INTO `category` (`icon`,`iconunicode`,`categoryname`,`link`,`banner`,`image`,`description`,`menu`,`sidebar`,`quickmenu`,`metatitle`,`metakeywords`,`metadescription`,`status`,`ip`,`updated_by`,`order`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($f) . "','" . trim($g) . "','" . trim($h) . "','" . trim($i) . "','" . trim($j) . "','" . trim($k) . "','" . trim($l) . "','" . trim($m) . "','" . trim($n) . "','" . trim($o) . "','" . $_SESSION['UID'] . "','" . trim($q) . "')");

            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Master','2','Insert','" . $_SESSION['UID'] . "','" . $o . "','" . $insert_id . "')");

            $resa = mysql_query("UPDATE `category` SET `modeoperation`='1' WHERE `cid`='$insert_id'");
            mysql_query("UPDATE `api_validation` SET `mode`='1' WHERE `tablename`='category'");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Category or Link!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `cid` FROM `category` WHERE (`categoryname`='" . trim($c) . "' OR `link`='" . trim($d) . "') AND `status`!='2' AND `cid`!='$p'");
        if ($ress['cid'] == '') {
            $resa = mysql_query("UPDATE `category` SET `categoryname`='" . trim($c) . "',`icon`='" . trim($a) . "',`iconunicode`='" . trim($b) . "',`link`='" . trim($d) . "',`banner`='" . trim($e) . "',`image`='" . trim($f) . "',`description`='" . trim($g) . "',`menu`='" . trim($h) . "',`sidebar`='" . trim($i) . "',`quickmenu`='" . trim($j) . "',`metatitle`='" . trim($k) . "',`metakeywords`='" . trim($l) . "',`metadescription`='" . trim($m) . "',`status`='" . trim($n) . "',`ip`='" . trim($o) . "',`order`='" . trim($q) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `cid`='" . trim($p) . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Master','2','Update','" . $_SESSION['UID'] . "','" . $o . "','" . $p . "')");

            $resa = mysql_query("UPDATE `category` SET `modeoperation`='2' WHERE `cid`='$p'");
            mysql_query("UPDATE `api_validation` SET `mode`='2' WHERE `tablename`='category'");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Category or Link!</h4></div>';
        }
    }

    return $res;
}

function getcategory($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `category` WHERE `cid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delcategory($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `category` WHERE `cid` ='" . $c . "' ");
        //$resa = mysql_query("UPDATE `category` SET `modeoperation`='3' WHERE `cid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function getagent($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `agent` WHERE `aid`='$b'"));
    $res = $get[$a];
    return $res;
}

function getagent1($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `agent` WHERE `agent_id`='$b'"));
    $res = $get[$a];
    return $res;
}

function getcomp($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `company` WHERE `comid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delagent($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query(" DELETE FROM `agent`  WHERE `aid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addtaxmaster.htm">Try Again</a>--></div>';
    return $res;
}

function addsubcategory($a, $l, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k, $m, $n,$o) {
    if ($k == '') {
        $ress = DB_QUERY("SELECT `scid` FROM `subcategory` WHERE (`subcategoryname`= '" . $b . "'  OR `link`= '" . $c . "') AND `status`!='2'");
        if ($ress['scid'] == '') {
            $resa = mysql_query("INSERT INTO `subcategory` (`category`,`type`,`subcategoryname`,`link`,`banner`,`image`,`metatitle`,`metakeywords`,`metadescription`,`status`,`ip`,`updated_by`,`attributeset`,`order`,`icon`) VALUES ('" . trim($a) . "','" . trim($l) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($f) . "','" . trim($g) . "','" . trim($h) . "','" . trim($i) . "','" . trim($j) . "','" . $_SESSION['UID'] . "','".trim($m)."','".trim($n)."','".trim($o)."')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Sub Category Master','3','Insert','" . $_SESSION['UID'] . "','" . $e . "','" . $insert_id . "')");

            $resa = mysql_query("UPDATE `subcategory` SET `modeoperation`='1' WHERE `scid`='$insert_id'");

            mysql_query("UPDATE `api_validation` SET `mode`='1' WHERE `tablename`='subcategory'");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4><!--<a href="' . $sitename . 'settings/addsubcategory.htm">Add another one</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Subcategory or Link!</h4><!--<a href="' . $sitename . 'master/addsubcategory.htm">Try Again</a>--></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `scid` FROM `subcategory` WHERE (`subcategoryname`= '" . $b . "'  OR `link`= '" . $c . "')  AND `status`!='2' AND `scid`!='" . $k . "'");
        if ($ress['scid'] == '') {
            $resa = mysql_query("UPDATE `subcategory` SET `category`='" . trim($a) . "',`type`='" . trim($l) . "',`subcategoryname`='" . trim($b) . "',`link`='" . trim($c) . "',`banner`='" . trim($d) . "',`image`='" . trim($e) . "',`metatitle`='" . trim($f) . "',`metakeywords`='" . trim($g) . "',`metadescription`='" . trim($h) . "',`status`='" . trim($i) . "',`order`='" . trim($n) . "',`ip`='" . trim($j) . "',`updated_by`='" . $_SESSION['UID'] . "',`attributeset`='".trim($m)."',`icon`='".trim($o)."' WHERE `scid`='" . trim($k) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Subcategory','3','Update','" . $_SESSION['UID'] . "','" . $j . "','" . $k . "')");

            $resa = mysql_query("UPDATE `subcategory` SET `modeoperation`='2' WHERE `scid`='$k'");

            mysql_query("UPDATE `api_validation` SET `mode`='2' WHERE `tablename`='subcategory'");


            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4><!--<a href="' . $sitename . 'master/addsubcategory.htm">Back to Listings Page</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this SubCategory or Link!</h4><!--<a href="' . $sitename . 'master/addsubcategory.htm">Try Again</a>--></div>';
        }
    }
    //$res="SELECT `scid` FROM `subcategory` WHERE FIND_IN_SET('".$a."', `category`) AND `subcategoryname`= '" . $b . "'  AND `status`!='2' AND `scid`!='" . $k . "'";

    return $res;
}

function getsubcategory($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `subcategory` WHERE `scid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function delsubcategory($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `subcategory` WHERE `scid` ='" . $c . "' ");
        // $resa = mysql_query("UPDATE `subcategory` SET `modeoperation`='3' WHERE `scid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addsubcategory.htm">Try Again</a>--></div>';
    return $res;
}

function addemployees($deptid, $desigid, $basicsalary, $image, $title, $empname, $lastname, $gender, $dateofbirth, $email, $mobilenumber, $landline, $DoorNo, $StreetName, $address, $country, $state, $districtname, $locationname, $postcode, $paddress, $pcountry, $pstate, $pdistrictname, $plocationname, $ppostcode, $description, $status, $ip, $employee_auto_id, $emp_code) {


    if ($employee_auto_id == '') {
        $query = mysql_fetch_array(mysql_query("SELECT `eid` FROM `employeemaster` WHERE (`emailid`='" . trim($email) . "' OR `phoneno`='" . trim($mobilenumber) . "')"));

        if ($query['eid'] == '') {
            $resa = mysql_query("INSERT INTO `employeemaster` (`deptid`,`desigid`,`basicsalary`, `image`,`title`,`empname`,`lastname`, `gender`,`dateofbirth`,`email`,`mobilenumber`,`landlinenumber`,`doorno`,`streetname`,`address`,`country`,`state`,`district`,`location`, `postcode`, `peraddress`,`percountry`,`perstate`,`perdistrict`,`perlocation`,`perpostcode`,`description`,`status`,`ip`,`updated_by`,`empcode`) VALUES ('$deptid','$desigid','" . trim($basicsalary) . "', '$image', '$title', '" . trim($empname) . "','" . trim($lastname) . "', '$gender','$dateofbirth','" . trim($email) . "','" . trim($mobilenumber) . "','" . trim($landline) . "','" . trim($DoorNo) . "','" . trim($StreetName) . "','" . trim($address) . "','$country','$state','$districtname','$locationname', '$postcode','" . trim($paddress) . "','$pcountry','$pstate','$pdistrictname','$plocationname','$ppostcode','" . trim($description) . "','$status','$ip','" . $_SESSION['UID'] . "','".$emp_code."')");

            $insert_id = mysql_insert_id();

            //  $empid = 'NME' . str_pad(getlocation('lid', getemployees('sitelocid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad(getdepartment('did', getemployees('deptid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad(getdesignation('id', getemployees('desigid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad($insert_id, 5, '0', STR_PAD_LEFT);

//            $empcode = 'NME' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `employeemaster` SET `empcode`='$empcode' WHERE `eid`='$insert_id'");


            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','16','Insert','" . $_SESSION['UID'] . "','" . $ip . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-exclamation-triangle"></i> Email address or mobilenumber already exists</h4></div>';
        }
    } else {

        $query = mysql_fetch_array(mysql_query("SELECT `eid` FROM `employeemaster` WHERE (`emailid`='" . trim($email) . "' OR `phoneno`='" . trim($mobilenumber) . "') AND `eid`!='$employee_auto_id'"));

        if ($query['eid'] == '') {

            $resa = mysql_query("UPDATE `employeemaster` SET `deptid`='$deptid',`desigid`='$desigid',`basicsalary`='" . trim($basicsalary) . "', `image`='" . $image . "',`title`='$title',`empname`='" . trim($empname) . "',`lastname`='" . trim($lastname) . "', `gender`='$gender',`dateofbirth`='$dateofbirth',`email`='" . trim($email) . "',`mobilenumber`='" . trim($mobilenumber) . "',`landlinenumber`='" . trim($landline) . "',`doorno`='" . trim($DoorNo) . "',`streetname`='" . trim($StreetName) . "',`address`='" . trim($address) . "',`country`='$country',`state`='$state',`district`='$districtname',`location`='$locationname', `postcode`='$postcode', `peraddress`='" . trim($paddress) . "',`percountry`='$pcountry',`perstate`='$pstate',`perdistrict`='$pdistrictname',`perlocation`='$plocationname',`perpostcode`='$ppostcode',`description`='" . trim($description) . "',`status`='$status',`ip`='$ip',`updated_by`='" . $_SESSION['UID'] . "',`empcode`='$emp_code' WHERE `eid`='" . $employee_auto_id . "'");


            //  $empid = 'NME' . str_pad(getlocation('lid', getemployees('sitelocid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad(getdepartment('did', getemployees('deptid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad(getdesignation('id', getemployees('desigid', $insert_id)), 3, '0', STR_PAD_LEFT) . str_pad($insert_id, 5, '0', STR_PAD_LEFT);

//            $empcode = 'NME' . str_pad($employee_auto_id, 5, '0', STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `employeemaster` SET `empcode`='$empcode', WHERE `eid`='" . $employee_auto_id . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','16','Update','" . $_SESSION['UID'] . "','" . $ip . "','" . $employee_auto_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-exclamation-triangle"></i> Email address or mobilenumber already exists</h4></div>';
        }
    }

    return $res;
}

//get employees

function getemployees($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `employeemaster` WHERE `eid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delemployee($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','13','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `employeemaster` WHERE `eid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addtaxmaster.htm">Try Again</a>--></div>';
    return $res;
}

function addinnercategory($a, $b, $attribute, $c, $d, $e, $f, $g, $h, $i, $j, $k, $l) {

    if ($l == '') {
        $ress = DB_QUERY("SELECT `icid` FROM `innercategory` WHERE (`innercategoryname`= '" . $c . "' OR `link`= '" . $d . "') AND `status`!='2'");
        if ($ress['icid'] == '') {

            $resa = mysql_query("INSERT INTO `innercategory` (`category`,`subcategory`,`attributeset`,`innercategoryname`,`link`,`banner`,`image`,`metatitle`,`metakeywords`,`metadescription`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($attribute) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($f) . "','" . trim($g) . "','" . trim($h) . "','" . trim($i) . "','" . trim($j) . "','" . trim($k) . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Inner Category Master','4','Insert','" . $_SESSION['UID'] . "','" . $k . "','" . $insert_id . "')");

            $resa = mysql_query("UPDATE `innercategory` SET `modeoperation`='1' WHERE `icid`='$insert_id'");
            mysql_query("UPDATE `api_validation` SET `mode`='1' WHERE `tablename`='innercategory'");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Innercategory or Link!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `icid` FROM `innercategory` WHERE (`innercategoryname`= '" . $c . "' OR `link`= '" . $d . "') AND `status`!='2' AND `icid`!='" . $l . "'");
        if ($ress['icid'] == '') {
            $resa = mysql_query("UPDATE `innercategory` SET `category`='" . trim($a) . "',`subcategory`='" . trim($b) . "',`attributeset`='" . trim($attribute) . "',`innercategoryname`='" . trim($c) . "',`link`='" . trim($d) . "',`banner`='" . trim($e) . "',`image`='" . trim($f) . "',`metatitle`='" . trim($g) . "',`metakeywords`='" . trim($h) . "',`metadescription`='" . trim($i) . "',`status`='" . trim($j) . "',`ip`='" . trim($k) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `icid`='" . trim($l) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('innercategory','4','Update','" . $_SESSION['UID'] . "','" . $k . "','" . $l . "')");

            $resa = mysql_query("UPDATE `innercategory` SET `modeoperation`='2' WHERE `icid`='$l'");
            mysql_query("UPDATE `api_validation` SET `mode`='2' WHERE `tablename`='innercategory'");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4><!--<a href="' . $sitename . 'master/addinnercategory.htm">Back to Listings Page</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this InnerCategory or Link!</h4><!--<a href="' . $sitename . 'master/addinnercategory.htm">Try Again</a>--></div>';
        }
    }
    return $res;
}

function getinnercategory($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `innercategory` WHERE `icid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function delinnercategory($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `innercategory` WHERE `icid` ='" . $c . "' ");
        // $resa = mysql_query("UPDATE `innercategory` SET `modeoperation`='3' WHERE `icid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addinnercategory.htm">Try Again</a>--></div>';
    return $res;
}

function a($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `innercategory` WHERE `icid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}
function sendcustomer($FirstName,$EmailID,$PhoneNo,$Password,$ip){
    if($EmailID !=''){
        sendlogindetail($FirstName,$EmailID,$Password);
    }
   else{
         $message = 'Hi ' . $FirstName . ', Welcome to Nbaysmart. Your username : ' . $PhoneNo . ', Password:' . $Password . 'Thank you.';
               //echo $message;exit;    
                    sendsms('NBAYSI', $message, $PhoneNo, $ip, '1'); 
    }
}
function addcustomer($title, $FirstName, $LastName, $Type, $image, $DoorNo, $Address1, $Address2, $Addressverification, $districtname, $state, $Country, $locationname, $PostCode, $EmailID, $emailverification, $PhoneNo, $phonenoverification, $Password, $agnn, $usertype, $description, $updatedtype, $status, $ip, $v, $companytype, $companyname, $companyaddress, $phonenumber, $landlinenumber, $email, $website, $aboutservices, $companyimage, $img, $customer_id) {

    if ($v == '') {
        if ($EmailID == '' && $PhoneNo == '') {
            $ress = DB_QUERY("SELECT * FROM `customer` WHERE `status`!='2'");
        } else if ($EmailID != '' && $PhoneNo == '') {
            $ress = DB_QUERY("SELECT * FROM `customer` WHERE `emailid`='" . trim($EmailID) . "'  AND `status`!='2'");
        } else if ($EmailID == '' && $PhoneNo != '') {
            $ress = DB_QUERY("SELECT * FROM `customer` WHERE `phoneno`='" . trim($PhoneNo) . "'  AND `status`!='2'");
        } else {
            $ress = DB_QUERY("SELECT * FROM `customer` WHERE `emailid`='" . trim($EmailID) . "' OR `phoneno`='" . trim($PhoneNo) . "' AND `status`!='2'");
            //echo "SELECT * FROM `customer` WHERE `emailid`='" . trim($EmailID) . "' OR `phoneno`='" . trim($PhoneNo) . "' AND `status`!='2'";
        }
        if ($ress['cusid'] == '') {

            $resa = mysql_query("INSERT INTO `customer`(`title`,`firstname`,`lastname`,`type`,`image`,`doorno`,`address1`,`address2`,`addressverification`,`city`,`state`,`country`,`location`,`postcode`,`emailid`,`emailverification`,`phoneno`,`phonenoverification`,`password`,`agentcode`,`usertype`,`description`,`updatedtype`,`status`,`ip`,`updatedid`,`customerid`)VALUES ('" . trim($title) . "','" . trim($FirstName) . "','" . trim($LastName) . "','" . trim($Type) . "','" . trim($image) . "','" . trim($DoorNo) . "','" . trim($Address1) . "','" . trim($Address2) . "','" . trim($Addressverification) . "','" . trim($districtname) . "','" . trim($state) . "','" . trim($Country) . "','" . trim($locationname) . "','" . trim($PostCode) . "','" . trim($EmailID) . "','" . trim($emailverification) . "','" . trim($PhoneNo) . "','" . trim($phonenoverification) . "','" . trim($Password) . "','" . trim($agnn) . "','" . trim($usertype) . "','" . trim($description) . "','" . trim($updatedtype) . "','" . trim($status) . "','" . trim($ip) . "','" . $_SESSION['UID'] . "','".trim($customer_id)."')");

            $insert_id = mysql_insert_id();
             if($EmailID !=''){
        sendlogindetail($FirstName,$EmailID,$Password);
    }
   else{
         $message = 'Hi ' . $FirstName . ', Welcome to Nbaysmart. Your username : ' . $PhoneNo . ', Password:' . $Password . 'Thank you.';
               //echo $message;exit;    
                    sendsms('NBAYSI', $message, $PhoneNo, $ip, '1'); 
    }
//            $customer_id = 'NMC' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `customer` SET `customerid`='$customer_id' WHERE `cusid`='$insert_id'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Customer Master','12','Insert','" . $_SESSION['UID'] . "','" . $u . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Emaild or Phoneno!</h4></div>';
        }
    } else {
        $s = '';
        if (($PhoneNo != '') && ($EmailID != '')) {
            $ress = DB_QUERY("SELECT `cusid` FROM `customer` WHERE `status`!='2' AND AND ( `emailid`='" . trim($EmailID) . "' OR `phoneno`='" . trim($PhoneNo) . "') AND `cusid`!='" . $v . "'");
        } else if ($PhoneNo != '' && $EmailID == '') {
            $ress = DB_QUERY("SELECT `cusid` FROM `customer` WHERE `status`!='2' AND (`phoneno`='" . $PhoneNo . "') AND `cusid`!='" . $v . "'");
        } else if ($EmailID != '' && $PhoneNo == '') {
            $ress = DB_QUERY("SELECT `cusid` FROM `customer` WHERE `status`!='2' AND `emailid`='" . $EmailID . "' AND `cusid`!='" . $v . "'");
        } else {
            $ress = DB_QUERY("SELECT `cusid` FROM `customer` WHERE `status`!='2' AND `cusid`='" . $v . "' AND `emailid`='' AND `phoneno`=''");
        }


        if ($ress['cusid'] == '') {

            $resa = DB("UPDATE `customer` SET `title`='" . trim($title) . "',`firstname`='" . trim($FirstName) . "',`lastname`='" . trim($LastName) . "',`type`='" . trim($Type) . "',`image`='" . trim($image) . "',`doorno`='" . trim($DoorNo) . "',`address1`='" . trim($Address1) . "',`address2`='" . trim($Address2) . "',`addressverification`='" . trim($Addressverification) . "',`city`='" . trim($districtname) . "',`state`='" . trim($state) . "',`country`='" . trim($Country) . "',`location`='" . trim($locationname) . "',`postcode`='" . trim($PostCode) . "',`emailid`='" . trim($EmailID) . "',`emailverification`='" . trim($emailverification) . "',`phoneno`='" . trim($PhoneNo) . "',`phonenoverification`='" . trim($phonenoverification) . "',`password`='" . trim($Password) . "',`agentcode`='" . trim($agnn) . "',`usertype`='" . trim($usertype) . "',`description`='" . trim($description) . "',`updatedtype`='" . trim($updatedtype) . "',`status`='" . trim($status) . "',`ip`='" . trim($ip) . "',`updatedid`='" . $_SESSION['UID'] . "',`customerid`='" . trim($customer_id) . "' WHERE `cusid`='" . trim($v) . "'");

            if ($usertype == 1) {
                DB("UPDATE `company` SET `usertype`='1' WHERE `cusid`='" . trim($v) . "'");
            }else if ($usertype == 2) {
                DB("UPDATE `company` SET `usertype`='2' WHERE `cusid`='" . trim($v) . "'");
            }

//            $customer_id = 'NMC' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//
//            $resa = DB("UPDATE `customer` SET `customerid`='$customer_id' WHERE `cusid`='$insert_id'");

            $htry = DB("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Customer Master','12','Update','" . $_SESSION['UID'] . "','" . trim($u) . "','" . trim($v) . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We Already have this EmailId or Phoneno!</h4></div>';
        }
    }
    return $res;
}

function getcustomer($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `cusid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delcustomer($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        // $get = mysql_query("UPDATE `customer` SET `status`='2' WHERE `cusid` ='" . $c . "' ");
        $get = mysql_query("DELETE FROM `customer` WHERE `cusid` ='" . $c . "'");
        $get1 = mysql_query("DELETE FROM `company` WHERE `cusid`='" . $c . "'");
        $get2 = mysql_query("DELETE FROM `create_ads` WHERE `customerid`='" . $c . "'");
        $get3 = mysql_query("DELETE FROM `favourite` WHERE `cusid` ='" . $c . "'");
        $get4 = mysql_query("DELETE FROM `product-enquiry` WHERE `customerid` ='" . $c . "'");
        $get5 = mysql_query("DELETE FROM `review` WHERE `cusid`='" . $c . "'");
        $get6 = mysql_query("DELETE FROM `company_favourite` WHERE `cusid`='" . $c . "'");
        
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addtaxmaster.htm">Try Again</a>--></div>';
    return $res;
}

function addcustomertype($a, $b, $c, $d) {
    if ($d == '') {
        $ress = DB_QUERY("SELECT `ctid` FROM `customertype` WHERE `type`= '" . trim($a) . "' AND `status`!='2'");
        if ($ress['ctid'] == '') {
            $resa = mysql_query("INSERT INTO `customertype` (`type`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Customertype Master','11','Insert','" . $_SESSION['UID'] . "','" . trim($c) . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4><!--<a href="' . $sitename . 'settings/addcustomertype.htm">Add another one</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Customertype!</h4><!--<a href="' . $sitename . 'master/addcustomertype.htm">Try Again</a>--></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `ctid` FROM `customertype` WHERE `type`='" . $a . "' `ctid`!='" . $d . "' ");
        if ($ress['ctid'] == '') {
            $resa = mysql_query("UPDATE `customertype` SET `type`='" . trim($a) . "',`status`='" . trim($b) . "',`ip`='" . trim($c) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `ctid`='" . trim($d) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('customertype','11','Update','" . $_SESSION['UID'] . "','" . trim($c) . "','" . trim($d) . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4><!--<a href="' . $sitename . 'master/addcustomertype.htm">Back to Listings Page</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Customertype!</h4><!--<a href="' . $sitename . 'master/addcustomertype.htm">Try Again</a>--></div>';
        }
    }

    return $res;
}

function delcustomertype($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Category Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("UPDATE `customertype` SET `status`='2' WHERE `ctid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addcustomertype.htm">Try Again</a>--></div>';
    return $res;
}

function getcustomertype($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `customertype` WHERE `ctid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function addtype($a, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k) {
    if ($k == '') {
        $ress = DB_QUERY("SELECT `tid` FROM `typee` WHERE `typename`='" . $b . "'");
        if ($ress['tid'] == '') {
            $resa = mysql_query("INSERT INTO `typee` (`category`,`typename`,`link`,`banner`,`image`,`metatitle`,`metakeywords`,`metadescription`,`status`,`ip`,`updated_by`) VALUES ('" . $a . "','" . $b . "','" . $c . "','" . $d . "','" . $e . "','" . $f . "','" . $g . "','" . $h . "','" . $i . "','" . $j . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Type Master','5','Insert','" . $_SESSION['UID'] . "','" . $j . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Type!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `tid` FROM `typee` WHERE `typename`='" . $b . "' AND `tid`!='" . $k . "'");
        if ($ress['tid'] == '') {
            $resa = mysql_query("UPDATE `typee` SET `category`='" . $a . "',`typename`='" . $b . "',`link`='" . $c . "',`banner`='" . $d . "',`image`='" . $e . "',`metatitle`='" . $f . "',`metakeywords`='" . $g . "',`metadescription`='" . $h . "',`status`='" . $i . "',`ip`='" . $j . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `tid`='" . $k . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Type master','5','Update','" . $_SESSION['UID'] . "','" . $j . "','" . $k . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Type!</h4></div>';
        }
    }

    return $res;
}

function deltype($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Type Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `typee` WHERE `tid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function get_type($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `typee` WHERE `tid`='$b'"));
    $res = $get[$a];
    return $res;
}

function addservices($a, $b, $c, $d, $e, $f, $g) {
    if ($g == '') {
        $ress = DB_QUERY("SELECT `sid` FROM `services` WHERE `service_name`= '" . $a . "'");
        if ($ress['sid'] == '') {
            $resa = mysql_query("INSERT INTO `services` (`service_name`,`status`,`ip`,`metatitle`,`metakeywords`,`metadescription`,`updated_type`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . mysql_real_escape_string(trim($e)) . "','" . mysql_real_escape_string(trim($f)) . "','" . $g . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();

            $service_id = 'NMS' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);

            mysql_query("UPDATE `services` SET `service_id`='$service_id' WHERE `sid`='$insert_id'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Services','35','Insert','" . $_SESSION['UID'] . "','" . $c . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Services!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `sid` FROM `services` WHERE `service_name`='" . $a . "' AND `sid`!='" . $g . "'");
        if ($ress['sid'] == '') {
            $resa = mysql_query("UPDATE `services` SET `service_name`='" . trim($a) . "',`status`='" . trim($b) . "',`ip`='" . trim($c) . "',`metatitle`='" . trim($d) . "',`metakeywords`='" . mysql_real_escape_string(trim($e)) . "',`metadescription`='" . mysql_real_escape_string(trim($f)) . "',`updated_type`='" . $_SESSION['services_id'] . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `sid`='" . trim($g) . "'");

            $service_id = 'NMS' . str_pad($g, 5, '0', STR_PAD_LEFT);

            mysql_query("UPDATE `services` SET `service_id`='$service_id' WHERE `sid`='" . trim($g) . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Services','35','Update','" . $_SESSION['UID'] . "','" . $c . "','" . $g . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Services!</h4></div>';
        }
    }

    return $res;
}

function delservices($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Agent Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `services` WHERE `sid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function getservices($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `services` WHERE `sid`='$b'"));
    $res = $get[$a];
    return $res;
}

function addagenttype($a, $b, $c, $d) {
    if ($d == '') {
        $ress = DB_QUERY("SELECT `atid` FROM `agent_type` WHERE `agenttypename`= '" . $a . "' AND `status`!='2'");
        if ($ress['atid'] == '') {
            $resa = mysql_query("INSERT INTO `agent_type` (`agenttypename`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Agent type  Master','9','Insert','" . $_SESSION['UID'] . "','" . $c . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Agenttype!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `atid` FROM `agent_type` WHERE `agenttypename`='" . $a . "' AND `status`!='2' AND `atid`!='" . $d . "'");
        if ($ress['atid'] == '') {
            $resa = mysql_query("UPDATE `agent_type` SET `agenttypename`='" . trim($a) . "',`status`='" . trim($b) . "',`ip`='" . trim($c) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `atid`='" . trim($d) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('agent type Master','9','Update','" . $_SESSION['UID'] . "','" . $c . "','" . $d . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Agenttype!</h4></div>';
        }
    }

    return $res;
}

function delagenttype($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Agent Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("UPDATE `agent_type` SET `status`='2' WHERE `atid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function getagenttype($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `agent_type` WHERE `atid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function adduser($a, $b, $c, $d, $e, $g, $h, $i) {
    if ($i == '') {
        $ress = DB_QUERY("SELECT `uid` FROM `usermaster` WHERE `username`='" . trim($a) . "' AND `status`!='2'");

        if ($ress['uid'] == '') {
            $resa = mysql_query("INSERT INTO `usermaster` (`username`,`password`,`changepwd`,`userid`,`permissiongroup`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . $b . "','" . $c . "','" . $d . "','" . $e . "','" . $g . "','" . $h . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('User Master','15','Insert','" . $_SESSION['UID'] . "','" . $e . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this UserName!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `uid` FROM `usermaster` WHERE (`username`='" . trim($a) . "' OR `userid`='" . trim($d) . "') AND `status`!='2' AND `uid`!='" . $i . "'");
        if ($ress['uid'] == '') {
            $resa = mysql_query("UPDATE `usermaster` SET `username`='" . trim($a) . "',`password`='" . $b . "',`changepwd`='" . $c . "',`userid`='" . $d . "',`permissiongroup`='" . $e . "',`status`='" . $g . "',`ip`='" . $h . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `uid`='" . $i . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('User Master','15','Update','" . $_SESSION['UID'] . "','" . $h . "','" . $i . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this UserName!</h4></div>';
        }
    }
//echo "INSERT INTO `usermaster` (`username`,`password`,`changepwd`,`userid`,`permissiongroup`,`sitelocid`,`status`,`ip`,`updated_by`) VALUES ('" . $a . "','" . $b . "','" . $c . "','" . $d . "','" . $e . "','" . $f . "','" . $g . "','" . $h . "','" . $_SESSION['UID'] . "')";
//
//echo "UPDATE `usermaster` SET `username`='" . $a . "',`password`='" . $b . "',`changepwd`='" . $c . "',`userid`='" . $d . "',`permissiongroup`='" . $e . "',`sitelocid`='" . $f . "',`status`='" . $g . "',`ip`='" . $h . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `uid`='" . $i . "'";
//exit;
    return $res;
}

function getusers($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `usermaster` WHERE `uid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function deluser($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('User Master','12','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `usermaster` WHERE `uid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addtaxmaster.htm">Try Again</a>--></div>';
    return $res;
}

function addadvertis($posttype, $a, $b, $c, $e, $f, $g, $h, $i, $j, $k, $l, $search, $specification, $specification_val, $productcheckbox, $producttype, $availableqty, $purchaseqty, $m, $p, $s, $q, $shortdescription, $r, $DoorNo, $Address1, $Address2, $Country, $state, $districtname, $PostCode, $contactname, $contactno, $advertising_id, $addid, $att1, $contactemail,$agnn,$updatedtype,$sendnotify) {

    $check = DB_QUERY("SELECT * FROM  `customer` WHERE `cusid`='" . $b . "'");
    $wallet_amount = $check['wallet_amount'];
    $changewallet = $wallet_amount;
    $sec = '';
    if ($a == 2) {
        $changewallet = $wallet_amount - 20;

        $sec = "`adtype`='" . $a . "'";
    }
    else {
            $a= '1';
        }
   
    if ($r == '') {
        if ($ress['id'] == '') {
            
           if($b!=''){
               if(($check['address2']=='') && ($check['address1']==''))
               {
                   DB("UPDATE `customer` SET `address2`='".mysql_real_escape_string($Address2)."',`address1`='".mysql_real_escape_string($Address1)."',`city`='".mysql_real_escape_string($districtname)."',`state`='".mysql_real_escape_string($state)."',`country`='".mysql_real_escape_string($Country)."',`postcode`='".$PostCode."' where `cusid`='".$b."'");
               }
                
                if($check['city']=='')
               {
                   DB("UPDATE `customer` SET `city`='".mysql_real_escape_string($districtname)."' where `cusid`='".$b."'");
                   
               }
               if($check['state']=='')
               {
                   DB("UPDATE `customer` SET `state`='".mysql_real_escape_string($state)."' where `cusid`='".$b."'");
                   
               }
               if($check['country']=='')
               {
                   DB("UPDATE `customer` SET `country`='".mysql_real_escape_string($Country)."' where `cusid`='".$b."'");
                   
               }
                if($check['postcode']=='')
               {
                   DB("UPDATE `customer` SET `postcode`='".$PostCode."' where `cusid`='".$b."'");
                   
               }
            $resa = DB("INSERT INTO `create_ads` (`posttype`,`adtype`,`customerid`,`agent_id`,`category`,`subcategory`,`innercategory`,`adtitle`,`link`,`originalprice`,`offerprice`,`addesc`,`searchkeywords`,`specification`,`specification_val`,`productcheckbox`,`producttype`,`availableqty`,`purchaseqty`,`images`,`status`,`ip`,`shortdesc`,`updated_by`,`admin_status`,`doorno`,`streetaddress`,`address`,`country`,`state`,`districtname`,`postcode`,`contactname`,`contactno`,`advertising_id`,`id`,`attribute`,`updated_type`,`customer_verified`) VALUES ('" . $posttype . "','" . $a . "','" . $b . "','" . $c . "','" . $e . "','" . $f . "','" . $g . "','" . mysql_real_escape_string($h) . "','" . trim($i) . "','" . trim($j) . "','" . trim($k) . "','" . mysql_real_escape_string($l) . "','" .  mysql_real_escape_string($search) . "','" . implode('$$$', $specification) . "','" . implode('$$$', $specification_val) . "','" . $productcheckbox . "','" . $producttype . "','" . trim($availableqty) . "','" . trim($purchaseqty) . "','" . $m . "','" . $p . "','" . $q . "','" .  mysql_real_escape_string($shortdescription) . "','" . $_SESSION['UID'] . "','".$s."','" . $DoorNo . "','" . mysql_real_escape_string($Address1) . "','" . mysql_real_escape_string($Address2) . "','" . mysql_real_escape_string($Country) . "','" . mysql_real_escape_string($state) . "','" .  mysql_real_escape_string($districtname) . "','" . $PostCode . "','" .  mysql_real_escape_string($contactname) . "','" . $contactno . "','" . $advertising_id . "','" . $addid . "','".$att1."','".$updatedtype."','1')");

            $insert_id = mysql_insert_id();

            $percentage = (100) - ($k / $j * 100);

            mysql_query("UPDATE `create_ads` SET `percentage`='" . $percentage . "' WHERE `id`='$insert_id'");

            $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='1' AND `admin_status`='0' WHERE `id`='$insert_id'");

//            $advertising_id = 'NM' . str_pad(getadvertis('category', $insert_id), 2, '0', STR_PAD_LEFT) . str_pad(getadvertis('subcategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad(getadvertis('innercategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad($insert_id, STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `create_ads` SET `advertising_id`='$advertising_id' WHERE `id`='$insert_id'");
            $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$changewallet' WHERE `cusid`='" . $b . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising master','14','Insert','" . $_SESSION['UID'] . "','" . $q . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';

            /* mail advertisement start */
            //ad_mail_insert($insert_id);

            $mysel = DB_QUERY("SELECT * FROM `create_ads` WHERE `id` =$insert_id");

            if ($mysel['admin_status'] == '1') {

                if ($mysel['adtype'] != '2') {
                    $curdate = date('Y-m-d');
                    $s = '';
                    if ($mysel['numdays'] == '0') {
                       $final = date("Y-m-d", strtotime("+1 month"));
                       $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                      $diff = Coundays($curdate, $final1);
//                        $final1='';
//                        $diff='';
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                       $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                       $diff = Coundays($curdate, $final1);
//                        $final='';
//                        $diff='';
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                } else {
                    $curdate = date('Y-m-d');
                    // $diff=0;
                    // $final=0;
                    //echo $curdate;
                    if (($mysel['numdays'] == '0')) {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                        //  echo $diff;
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                }
                if($sendnotify == '1'){
               if (getcustomer('emailid', getadvertis('customerid', $insert_id)) != '') {
                ad_approve_mail($insert_id);
               }else{
                    $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $insert_id)) . ',Your advertisement with nbaysmart live Please visit nbaysmart.com for more details. Your Advertisement_id : ' . getadvertis('advertising_id', $insert_id) . ' Thank you';
                    
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');
               }
                }
            }
        }else{
            if ($contactno != '' && $contactemail == '') {
            $retest = DB_QUERY("SELECT * FROM `customer` WHERE `phoneno`='" . trim($contactno) . "'");
        } elseif ($contactno == '' && $contactemail != '') {
            $retest = DB_QUERY("SELECT * FROM `customer` WHERE `emailid`='" . trim($contactemail) . "'");
        } elseif ($contactno != '' && $contactemail != '') {
            $retest = DB_QUERY("SELECT * FROM `customer` WHERE `emailid`='" . trim($contactemail) . "' OR `phoneno`='" . trim($contactno) . "' ");
        }else{}
        if($retest!=''){
             if(($retest['address2']=='') && ($retest['address1']==''))
               {
                   DB("UPDATE `customer` SET `address2`='".mysql_real_escape_string($Address2)."',`address1`='".mysql_real_escape_string($Address1)."',`city`='".mysql_real_escape_string($districtname)."',`state`='".mysql_real_escape_string($state)."',`country`='".mysql_real_escape_string($Country)."',`postcode`='".$PostCode."' where `cusid`='".$retest['cusid']."'");
               }
               
                if($retest['city']=='')
               {
                   DB("UPDATE `customer` SET `city`='".mysql_real_escape_string($districtname)."' where `cusid`='".$retest['cusid']."'");
                   
               }
               if($retest['state']=='')
               {
                   DB("UPDATE `customer` SET `state`='".mysql_real_escape_string($state)."' where `cusid`='".$retest['cusid']."'");
                   
               }
               if($retest['country']=='')
               {
                   DB("UPDATE `customer` SET `country`='".mysql_real_escape_string($Country)."' where `cusid`='".$retest['cusid']."'");
                   
               }
                if($retest['postcode']=='')
               {
                   DB("UPDATE `customer` SET `postcode`='".$PostCode."' where `cusid`='".$retest['cusid']."'");
                   
               }
                    $resa = DB("INSERT INTO `create_ads` (`posttype`,`adtype`,`customerid`,`agent_id`,`category`,`subcategory`,`innercategory`,`adtitle`,`link`,`originalprice`,`offerprice`,`addesc`,`searchkeywords`,`specification`,`specification_val`,`productcheckbox`,`producttype`,`availableqty`,`purchaseqty`,`images`,`status`,`ip`,`shortdesc`,`updated_by`,`admin_status`,`doorno`,`streetaddress`,`address`,`country`,`state`,`districtname`,`postcode`,`contactname`,`contactno`,`advertising_id`,`id`,`attribute`,`updated_type`,`customer_verified`) VALUES ('" . $posttype . "','" . $a . "','" . $retest['cusid'] . "','" . $c . "','" . $e . "','" . $f . "','" . $g . "','" .  mysql_real_escape_string($h) . "','" . trim($i) . "','" . trim($j) . "','" . trim($k) . "','" .  mysql_real_escape_string($l) . "','" .  mysql_real_escape_string($search) . "','" . implode('$$$', $specification) . "','" . implode('$$$', $specification_val) . "','" . $productcheckbox . "','" . $producttype . "','" . trim($availableqty) . "','" . trim($purchaseqty) . "','" . $m . "','" . $p . "','" . $q . "','" .  mysql_real_escape_string($shortdescription) . "','" . $_SESSION['UID'] . "','".$s."','" . $DoorNo . "','" .  mysql_real_escape_string($Address1) . "','" .  mysql_real_escape_string($Address2) . "','" .  mysql_real_escape_string($Country) . "','" .  mysql_real_escape_string($state) . "','" .  mysql_real_escape_string($districtname) . "','" . $PostCode . "','" .  mysql_real_escape_string($contactname) . "','" . $contactno . "','" . $advertising_id . "','" . $addid . "','".$att1."','".$updatedtype."','1')");

            $insert_id = mysql_insert_id();

            $percentage = (100) - ($k / $j * 100);

            mysql_query("UPDATE `create_ads` SET `percentage`='" . $percentage . "' WHERE `id`='$insert_id'");

            $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='1' AND `admin_status`='0' WHERE `id`='$insert_id'");

//            $advertising_id = 'NM' . str_pad(getadvertis('category', $insert_id), 2, '0', STR_PAD_LEFT) . str_pad(getadvertis('subcategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad(getadvertis('innercategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad($insert_id, STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `create_ads` SET `advertising_id`='$advertising_id' WHERE `id`='$insert_id'");
            $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$changewallet' WHERE `cusid`='" . $b . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising master','14','Insert','" . $_SESSION['UID'] . "','" . $q . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';

            /* mail advertisement start */
            //ad_mail_insert($insert_id);

            $mysel = DB_QUERY("SELECT * FROM `create_ads` WHERE `id` =$insert_id");

            if ($mysel['admin_status'] == '1') {

                if ($mysel['adtype'] != '2') {
                    $curdate = date('Y-m-d');
                    $s = '';
                    if ($mysel['numdays'] == '0') {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
//                        $final1='';
//                        $diff='';
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                       $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
//                        $final='';
//                        $diff='';
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                } else {
                    $curdate = date('Y-m-d');
                    // $diff=0;
                    // $final=0;
                    //echo $curdate;
                    if (($mysel['numdays'] == '0')) {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                        //  echo $diff;
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                }
                  if($sendnotify == '1'){
               if (getcustomer('emailid', getadvertis('customerid', $insert_id)) != '') {
                ad_approve_mail($insert_id);
               }else{
                    $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $insert_id)) . ',Your advertisement with nbaysmart live Please visit nbaysmart.com for more details. Your Advertisement_id : ' . getadvertis('advertising_id', $insert_id) . ' Thank you';
                    
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');
               }
                  }
            }
        }
            else{
            $random = mt_rand(100000, 999999);

                DB("INSERT INTO `customer` SET `firstname`='" .  mysql_real_escape_string($contactname) . "',`emailid`='" . $contactemail . "',`phoneno`='" . $contactno . "',`password`='" . $random . "',`ip`='".$q."',`updatedtype`='".$updatedtype."',`agentcode`='".$agnn."',`status`='1',`address2`='". mysql_real_escape_string($Address2)."',`address1`='".mysql_real_escape_string($Address1)."',`city`='". mysql_real_escape_string($districtname)."',`state`='". mysql_real_escape_string($state)."',`country`='". mysql_real_escape_string($Country)."',`postcode`='".$PostCode."',`usertype`='1'");

                $insert_id1 = mysql_insert_id();
                 $customer_id = 'NMC' . str_pad($insert_id1, 5, '0', STR_PAD_LEFT);
                 $resa = mysql_query("UPDATE `customer` SET `customerid`='$customer_id' WHERE `cusid`='$insert_id1'");
                if ($contactemail != ''&& $contactno =='') {
                    verificationmail1($contactemail, $insert_id1);
                   // exit;
                }
                elseif($contactno!='' && $contactemail == ''){
                    $message = 'Hi ' . getcustomer('firstname', $insert_id1) . ', Welcome to Nbaysmart. Your username : ' . $contactno . ', Password:' . $random . 'Thank you';
                   
                    sendsms('NBAYSI', $message, $contactno, $ip, '1'); 
                }
                else{
                   verificationmail1($contactemail, $insert_id1);  
                }
                
                 $resa = DB("INSERT INTO `create_ads` (`posttype`,`adtype`,`customerid`,`agent_id`,`category`,`subcategory`,`innercategory`,`adtitle`,`link`,`originalprice`,`offerprice`,`addesc`,`searchkeywords`,`specification`,`specification_val`,`productcheckbox`,`producttype`,`availableqty`,`purchaseqty`,`images`,`status`,`ip`,`shortdesc`,`updated_by`,`admin_status`,`doorno`,`streetaddress`,`address`,`country`,`state`,`districtname`,`postcode`,`contactname`,`contactno`,`advertising_id`,`id`,`attribute`,`updated_type`,`customer_verified`) VALUES ('" . $posttype . "','" . $a . "','" . $insert_id1 . "','" . $c . "','" . $e . "','" . $f . "','" . $g . "','" .  mysql_real_escape_string($h) . "','" . trim($i) . "','" . trim($j) . "','" . trim($k) . "','" .  mysql_real_escape_string($l) . "','" .  mysql_real_escape_string($search) . "','" . implode('$$$', $specification) . "','" . implode('$$$', $specification_val) . "','" . $productcheckbox . "','" . $producttype . "','" . trim($availableqty) . "','" . trim($purchaseqty) . "','" . $m . "','" . $p . "','" . $q . "','" .  mysql_real_escape_string($shortdescription) . "','" . $_SESSION['UID'] . "','".$s."','" . $DoorNo . "','" .  mysql_real_escape_string($Address1) . "','" .  mysql_real_escape_string($Address2) . "','" .  mysql_real_escape_string($Country) . "','" .  mysql_real_escape_string($state) . "','" .  mysql_real_escape_string($districtname) . "','" . $PostCode . "','" .  mysql_real_escape_string($contactname) . "','" . $contactno . "','" . $advertising_id . "','" . $addid . "','".$att1."','".$updatedtype."','1')");

            $insert_id = mysql_insert_id();

            $percentage = (100) - ($k / $j * 100);

            mysql_query("UPDATE `create_ads` SET `percentage`='" . $percentage . "' WHERE `id`='$insert_id'");

            $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='1' AND `admin_status`='0' WHERE `id`='$insert_id'");

//            $advertising_id = 'NM' . str_pad(getadvertis('category', $insert_id), 2, '0', STR_PAD_LEFT) . str_pad(getadvertis('subcategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad(getadvertis('innercategory', $insert_id), 3, '0', STR_PAD_LEFT) . str_pad($insert_id, STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `create_ads` SET `advertising_id`='$advertising_id' WHERE `id`='$insert_id'");
            $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$changewallet' WHERE `cusid`='" . $b . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising master','14','Insert','" . $_SESSION['UID'] . "','" . $q . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';

            /* mail advertisement start */
            //ad_mail_insert($insert_id);

            $mysel = DB_QUERY("SELECT * FROM `create_ads` WHERE `id` =$insert_id");

            if ($mysel['admin_status'] == '1') {

                if ($mysel['adtype'] != '2') {
                    $curdate = date('Y-m-d');
                    $s = '';
                    if ($mysel['numdays'] == '0') {
                        $final = date("Y-m-d", strtotime("+1 month"));
                       $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                       $diff = Coundays($curdate, $final1);
//                        $final1='';
//                        $diff='';
                    } else {
                       $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                      $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                      $diff = Coundays($curdate, $final1);
//                        $final='';
//                        $diff='';
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                } else {
                    $curdate = date('Y-m-d');
                    // $diff=0;
                    // $final=0;
                    //echo $curdate;
                    if (($mysel['numdays'] == '0')) {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $mysel['numdays'] . " day"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                        //  echo $diff;
                    }
                    DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`=$insert_id");
                }  if($sendnotify == '1'){
               if (getcustomer('emailid', getadvertis('customerid', $insert_id)) != '') {
                ad_approve_mail($insert_id);
               }else{
                    $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $insert_id)) . ',Your advertisement with nbaysmart live Please visit nbaysmart.com for more details. Your Advertisement_id : ' . getadvertis('advertising_id', $insert_id) . ' Thank you';
                    
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');
               }
                }
            }
                
        }
        
        }
        }
    } else {

        if ($ress['id'] == '') {
            $checkres = DB_QUERY("SELECT `adtype`,`updated_type`,`updated_by` FROM `create_ads` WHERE `id`='" . $r . "'");
            if($checkres['updated_type']=='3' || $checkres['updated_type']=='4' )
            {
                $updated_type1=$checkres['updated_type'];
                $updated_by =$checkres['updated_by'];
            }
            else{
                $updated_type1=$updatedtype;
                $updated_by= $_SESSION['UID'];
            }
             if(($check['address2']=='') && ($check['address1']==''))
               {
                   DB("UPDATE `customer` SET `address2`='".mysql_real_escape_string($Address2)."',`address1`='".mysql_real_escape_string($Address1)."',`city`='".mysql_real_escape_string($districtname)."',`state`='".mysql_real_escape_string($state)."',`country`='".mysql_real_escape_string($Country)."',`postcode`='".$PostCode."' where `cusid`='".$b."'");
               }
                
                if($check['city']=='')
               {
                   DB("UPDATE `customer` SET `city`='".mysql_real_escape_string($districtname)."' where `cusid`='".$b."'");
                   
               }
               if($check['state']=='')
               {
                   DB("UPDATE `customer` SET `state`='".mysql_real_escape_string($state)."' where `cusid`='".$b."'");
                   
               }
               if($check['country']=='')
               {
                   DB("UPDATE `customer` SET `country`='".mysql_real_escape_string($Country)."' where `cusid`='".$b."'");
                   
               }
                if($check['postcode']=='')
               {
                   DB("UPDATE `customer` SET `postcode`='".$PostCode."' where `cusid`='".$b."'");
                   
               }
              $resa = mysql_query("UPDATE `create_ads` SET `posttype`='" . $posttype . "',`customerid`='" . $b . "',`agent_id`='" . $c . "',`category`='" . $e . "',`subcategory`='" . $f . "',`innercategory`='" . $g . "',`adtitle`='" . mysql_real_escape_string($h) . "',`link`='" . $i . "',`originalprice`='" . $j . "',`offerprice`='" . $k . "',`addesc`='" . mysql_real_escape_string($l) . "',`searchkeywords`='" . mysql_real_escape_string($search) . "',`specification`='" . implode('$$$', $specification) . "',`specification_val`='" . implode('$$$', $specification_val) . "',`productcheckbox`='" . $productcheckbox . "',`producttype`='" . $producttype . "',`availableqty`='" . $availableqty . "',`purchaseqty`='" . $purchaseqty . "',`images`='" . mysql_real_escape_string($m) . "',`status`='" . $p . "',`admin_status`='" . $s . "',`ip`='" . $q . "',`shortdesc`='" . mysql_real_escape_string($shortdescription) . "',`updated_by`='" . $updated_by . "',`doorno`='" . $DoorNo . "',`streetaddress`='" . mysql_real_escape_string($Address1) . "',`address`='" . mysql_real_escape_string($Address2) . "',`country`='" . mysql_real_escape_string($Country) . "',`state`='" . mysql_real_escape_string($state) . "',`districtname`='" . mysql_real_escape_string($districtname) . "',`postcode`='" . mysql_real_escape_string($PostCode) . "',`contactname`='" . mysql_real_escape_string($contactname) . "',`contactno`='" . $contactno . "',`advertising_id`='" . $advertising_id . "',`id`='" . $addid . "',`attribute`='".$att1."',`updated_type`='".$updated_type1."',`customer_verified`='1' WHERE `id`='" . $r . "'");
            DB("UPDATE `create_ads` SET $sec WHERE `id`='$r'");
            $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$changewallet' WHERE `cusid`='" . $b . "'");
            $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='2' WHERE `id`='$r'");

            $percentage = number_format((100) - ($k / $j * 100), 0, '.', '');
            // DB("UPDATE `create_ads` SET `approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = DATE_ADD(`approved_date`, INTERVAL 1 MONTH) WHERE `id`='$r' AND `admin_status`='1'");
            mysql_query("UPDATE `create_ads` SET `percentage`='" . $percentage . "' WHERE `id`='$r'");

//            $advertising_id = 'NM' . str_pad(stripcslashes($e), 2, '0', STR_PAD_LEFT) . str_pad(stripcslashes($f), 3, '0', STR_PAD_LEFT) . str_pad(stripcslashes($g), 3, '0', STR_PAD_LEFT) . str_pad($r, STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `create_ads` SET `advertising_id`='$advertising_id' WHERE `id`='$r'");


            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Master','14','Update','" . $_SESSION['UID'] . "','" . $q . "','" . $r . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
            $addismail = mysql_fetch_array(mysql_query("SELECT * FROM `create_ads` WHERE `id`='" . $r . "'"));

            if ($addismail['admin_status'] == 2) {
                if ($addismail['adtype'] == 2) {
                    $addismailamount = mysql_fetch_array(mysql_query("SELECT * FROM `create_ads` WHERE `id`='" . $r . "'"));
                    $walletamount = mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `cusid`='" . $addismailamount['customerid'] . "'"));
                    $checkamount = $walletamount['wallet_amount'] + 20;
                    $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$checkamount' WHERE `cusid`='" . $addismailamount['customerid'] . "'");
                    //echo "UPDATE `customer` SET `wallet_amount`='$checkamount' WHERE `cusid`='" . $addismailamount['customerid']. "'";
                }
                  if($sendnotify == '1'){
                 if (getcustomer('emailid', getadvertis('customerid', $r)) != '') {
                ad_mail_dis($r);
                 }else{
                   $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $r)) . ',Your advertisement Disapproved by admin.Please contact admin to approved your advertisement . Your Advertisement_id : ' . getadvertis('advertising_id', $r) . ' Thank you';
                    
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');   
                 }
                  }
            }
            // $mysel = DB_QUERY("SELECT * FROM `create_ads` WHERE `id` ='" . $r . "'");
            if (($checkres['adtype'] == 1) && ($a == 2) && ($s == 1)) {

                $curdate = date('Y-m-d');
                $final = date("Y-m-d", strtotime("+1 month"));
                $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                $diff = Coundays($curdate, $final1);
                DB("UPDATE `create_ads` SET `expired`='0',`approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`='" . $r . "'");
            } else if ($addismail['admin_status'] == 1) {
                if ($addismail['adtype'] != '2') {
                    $curdate = date('Y-m-d');
                    $s = '';
                    if ($addismail['numdays'] == '0') {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                       $diff = Coundays($curdate, $final1);
//                         $final1='';
//                         $diff='';
                         
                    } else {
                       $final = date("Y-m-d", strtotime("+" . $addismail['numdays'] . " day"));
                       $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
//                        $final1='';
//                         $diff='';
                    }
                    DB("UPDATE `create_ads` SET `expired`='0',`approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`='" . $r . "'");
                } else {
                    $curdate = date('Y-m-d');
                    if (($addismail['numdays'] == '0')) {
                        $final = date("Y-m-d", strtotime("+1 month"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                    } else {
                        $final = date("Y-m-d", strtotime("+" . $addismail['numdays'] . " day"));
                        $final1 = date("Y-m-d", strtotime("-1 day", strtotime($final)));
                        $diff = Coundays($curdate, $final1);
                        //  echo $diff;
                    }
                    DB("UPDATE `create_ads` SET `expired`='0',`approved_date`='" . date("Y/m/d H:i:s") . "',`expdate` = '" . $final1 . "',`numdays`='" . $diff . "' WHERE `id`='" . $r . "'");
                }
                //if ((($checkres['adminstatus'] == 0) || ($checkres['adminstatus'] == 2)) &&  ($s == 1)) {
                  if($sendnotify == '1'){
                if (getcustomer('emailid', getadvertis('customerid', $r)) != '') {
                ad_approve_mail($r);
                }else{
                  $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $r)) . ',Your advertisement with nbaysmart live Please visit nbaysmart.com for more details. Your Advertisement_id : ' . getadvertis('advertising_id', $r) . ' Thank you';
                   //echo $message;exit;
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');  
                }
                }
            }

            /* mail advertisement update start */
            // ad_mail_update($r);
            /* mail advertisement update end */
        }
    }

    return $res;
}

function getadvertis($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `create_ads` WHERE `id`='$b'"));
    $res = $get[$a];
    return $res;
}

function deladvertis($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Adverting Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $image = explode(",", getadvertis('images', $c));
        $uimg = '';
        foreach ($image as $images) {
            if ($images != '') {
                unlink("../../adthump/" . $images);
                unlink("../../adm/" . $images);
                unlink("../../adl/" . $images);
            }
        }
        $adid=getadvertis('advertising_id', $c);
        $get = mysql_query("DELETE FROM `create_ads` WHERE `id` ='" . $c . "'");
        $get1 = mysql_query("DELETE FROM `favourite` WHERE `id` ='" . $c . "'");
        $get2 = mysql_query("DELETE FROM `product-enquiry` WHERE `adid` ='" . $adid . "'");  
        $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='3' WHERE `id`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

//echo "SELECT * FROM `advertising` WHERE `advid`='$b' AND `status`!='2'";
//exit;

function getallemploye($a) {
    $fget = mysql_query("SELECT * FROM `employeemaster` WHERE `status`!='2' and `email` !=''");
    $optb = '';
    while ($get = mysql_fetch_array($fget)) {
        $selval = '';
        if ($get['eid'] == $a) {
            $selval = 'selected="selected"';
        }
        $ashp = $get['eid'] . "##&&**" . $get['email'];
        //$ashp=$get['eid'];
        $optb.='<option value="' . $ashp . '"  ' . $selval . '>' . $get['empname'] . ', ' . getdepartment("department", $get['deptid']) . ',' . getdesignation("designation", $get['desigid']) . ',' . getlocation("location", $get['sitelocid']) . '</option>';
    }


    return $optb;
}

function getallagents($a) {
    $fget = mysql_query("SELECT * FROM `agent` WHERE `status`!='2' and `emailid` !=''");
    $optb = '';
    while ($get = mysql_fetch_array($fget)) {
        $selval = '';
        if ($get['agent_id'] == $a) {
            $selval = 'selected="selected"';
        }
        $ashp = $get['agent_id'] . "##&&**" . $get['emailid'];
        $ashp = $get['agent_id'];
        $optb.='<option value="' . $ashp . '"  ' . $selval . '>' . $get['firstname'] . ' ' . $get['lastname'] . ',' . getdistrict('districtname', $get['district']) . ',' . getlocationl("locationname", $get['location']) . '</option>';
    }


    return $optb;
}

function getallpergrp($a) {
    $fget = mysql_query("SELECT * FROM `permission` WHERE `status`!='2'");
    $optb = '';
    while ($get = mysql_fetch_array($fget)) {
        $selval = '';
        if ($get['pid'] == $a) {
            $selval = 'selected="selected"';
        }
        $ashp = $get['pid'];
        //$ashp=$get['eid'];
        $optb.='<option value="' . $ashp . '"  ' . $selval . '>' . $get['name'] . '</option>';
    }


    return $optb;
}

function addadvertisingtype($a, $b, $c, $d) {
    if ($d == '') {
        $ress = DB_QUERY("SELECT `adid` FROM `advertising_type` WHERE `advertisingtypename`= '" . trim($a) . "' AND `status`!='2'");
        if ($ress['adid'] == '') {
            $resa = mysql_query("INSERT INTO `advertising_type` (`advertisingtypename`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Type Master','13','Insert','" . $_SESSION['UID'] . "','" . trim($c) . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this advertisingtype!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `adid` FROM `advertising_type` WHERE `advertisingtypename`='" . trim($a) . "' AND `adid`!='" . $d . "'");
        if ($ress['adid'] == '') {
            $resa = mysql_query("UPDATE `advertising_type` SET `advertisingtypename`='" . trim($a) . "',`status`='" . trim($b) . "',`ip`='" . trim($c) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `adid`='" . trim($d) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Type Master','13','Update','" . $_SESSION['UID'] . "','" . trim($c) . "','" . trim($d) . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Advertising type!</h4></div>';
        }
    }

    return $res;
}

function getadvertisingtype($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `advertising_type` WHERE `adid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function deladvertisingtype($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Adverting Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `advertising_type` WHERE `adid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addloc($a, $b, $c, $d, $e, $f) {
    if ($f == '') {
        $ress = DB_QUERY("SELECT `locid` FROM `loc` WHERE `locname`= '" . trim($a) . "' AND `status`!='2'");
        if ($ress['locid'] == '') {
            $resa = mysql_query("INSERT INTO `loc` (`locname`,`session_value`,`order`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . $_SESSION['UID'] . "')");
            // echo "INSERT INTO `loc` (`locname`,`session_value`,`order`,`status`,`ip`,`updated_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . $_SESSION['UID'] . "')";
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Type Master','13','Insert','" . $_SESSION['UID'] . "','" . trim($c) . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this advertisingtype!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `locid` FROM `loc` WHERE `locname`='" . trim($a) . "' AND `locid`!='" . $f . "'");
        if ($ress['locid'] == '') {
            $resa = mysql_query("UPDATE `loc` SET `locname`='" . trim($a) . "',`session_value`='" . trim($b) . "',`order`='" . trim($c) . "',`status`='" . trim($d) . "',`ip`='" . trim($e) . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `locid`='" . trim($f) . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Type Master','13','Update','" . $_SESSION['UID'] . "','" . trim($c) . "','" . trim($d) . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Advertising type!</h4></div>';
        }
    }

    return $res;
}

function getloc($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `loc` WHERE `locid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function delloc($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Adverting Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `loc` WHERE `locid` ='" . $c . "' ");
        // echo "DELETE FROM `loc` WHERE `locid` ='" . $c . "' ";
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addstate($a, $b, $c, $d, $e, $f, $g, $h, $i, $j) {
    if ($j == '') {
        $ress = DB_QUERY("SELECT `stid` FROM `state` WHERE `statename`= '" . $a . "' AND `status`!='2'");
        if ($ress['stid'] == '') {
            $resa = mysql_query("INSERT INTO `state` (`statename`,`link`,`image`,`description`,`metatitle`,`metakeywords`,`metadescription`,`status`,`ip`,`updated_by`) VALUES (
		
		
		'" . $a . "',		'" . $b . "',		'" . $c . "',		'" . $d . "',		'" . $e . "',		'" . $f . "',		'" . $g . "',
		'" . $h . "',		'" . $i . "',		'" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('State Master','6','Insert','" . $_SESSION['UID'] . "','" . $i . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this State!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `stid` FROM `state` WHERE `statename`='" . $a . "' AND `status`!='2' AND `stid`!='" . $j . "'");
        if ($ress['stid'] == '') {
            $resa = mysql_query("UPDATE `state` SET 
			`statename`='" . $a . "',
			`link`='" . $b . "',
			`image`='" . $c . "',
			`description`='" . $d . "',
			`metatitle`='" . $e . "',
			`metakeywords`='" . $f . "',
			`metadescription`='" . $g . "',		
			`status`='" . $h . "',`ip`='" . $i . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `stid`='" . $j . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('State Master','6','Update','" . $_SESSION['UID'] . "','" . $i . "','" . $j . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this State!</h4></div>';
        }
    }

    return $res;
}

function getstate($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `state` WHERE `stid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function delstate($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','13','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("UPDATE `state` SET `status`='2' WHERE `stid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function adddistrict($a, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k) {
    if ($k == '') {
        $ress = DB_QUERY("SELECT `diid` FROM `district` WHERE `districtname`= '" . $b . "' AND `status`!='2'");
        if ($ress['diid'] == '') {
            $resa = mysql_query("INSERT INTO `district` (
			`state`,
			`districtname`,
			`link`,
			`image`,
			`description`,
			`metatitle`,
			`metakeywords`,
			`metadescription`,
			`status`,
			`ip`,
			`updated_by`
			) VALUES (
		
		
		'" . $a . "',
		'" . $b . "',
		'" . $c . "',
		'" . $d . "',
		'" . $e . "',
		'" . $f . "',
		'" . $g . "',
		'" . $h . "',
		'" . $i . "',
		'" . $j . "',
       '" . $_SESSION['UID'] . "')");

            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('District Master','7','Insert','" . $_SESSION['UID'] . "','" . $j . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this State!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `diid` FROM `district` WHERE `districtname`='" . $b . "' AND `status`!='2' AND `diid`!='" . $k . "'");
        if ($ress['diid'] == '') {
            $resa = mysql_query("UPDATE `district` SET 
			`state`='" . $a . "',
			`districtname`='" . $b . "',
			`link`='" . $c . "',
			`image`='" . $d . "',
			`description`='" . $e . "',
			`metatitle`='" . $f . "',
			`metakeywords`='" . $g . "',
			`metadescription`='" . $h . "',		
			`status`='" . $i . "',`ip`='" . $j . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `diid`='" . $k . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Advertising Type Master','7','Update','" . $_SESSION['UID'] . "','" . $j . "','" . $k . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this District!</h4></div>';
        }
    }
    return $res;
}

function getdistrict($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `district` WHERE `diid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function deldistrict($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','13','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("UPDATE `district` SET `status`='2' WHERE `diid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addlocationl($a, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k, $l) {
    if ($l == '') {
        $ress = DB_QUERY("SELECT `loid` FROM `location` WHERE `locationname`= '" . $c . "' AND `status`!='2'");
        if ($ress['loid'] == '') {
            $resa = mysql_query("INSERT INTO `location` (`state`,
		`district`,
		`locationname`,
		`link`,
		`image`,
		`description`,
		`metatitle`,
		`metakeywords`,
		`metadescription`,
		`status`,
		`ip`,
		`updated_by`) VALUES (
		'" . $a . "',
		'" . $b . "',
		'" . $c . "',
		'" . $d . "',
		'" . $e . "',
		'" . $f . "',
		'" . $g . "',
		'" . $h . "',
		'" . $i . "',
		'" . $j . "',
		'" . $k . "',
		'" . $_SESSION['UID'] . "')");

            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Location Master','8','Insert','" . $_SESSION['UID'] . "','" . $k . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Location!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `loid` FROM `location` WHERE `locationname`='" . $c . "' AND `status`!='2' AND `loid`!='" . $l . "'");
        if ($ress['loid'] == '') {
            $resa = mysql_query("UPDATE `location` SET 
			`state`='" . $a . "',
			`district`='" . $b . "',
			`locationname`='" . $c . "',
			`link`='" . $d . "',
			`image`='" . $e . "',
			`description`='" . $f . "',
			`metatitle`='" . $g . "',
			`metakeywords`='" . $h . "',
			`metadescription`='" . $i . "',		
			`status`='" . $j . "',`ip`='" . $k . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `loid`='" . $l . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Location Master','8','Update','" . $_SESSION['UID'] . "','" . $k . "','" . $l . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Location!</h4></div>';
        }
    }
    return $res;
}

function getlocationl($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `location` WHERE `loid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function dellocationl($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Employee Master','13','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("UPDATE `location` SET `status`='2' WHERE `loid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addstaticpages($a, $b, $c, $d, $e, $f, $g, $h, $i) {

    $ress = DB_QUERY("SELECT `sid` FROM `static_pages` WHERE `status`!='2' AND `sid`!='$i'");
    if ($ress['sid'] == '') {
        $resa = mysql_query("UPDATE `static_pages` SET `metatitle`='" . trim(mysql_real_escape_string($a)) . "',`metakeywords`='" . trim(mysql_real_escape_string($b)) . "',`metadescription`='" . trim(mysql_real_escape_string($c)) . "',`banner`='" . $d . "',`image`='" . $e . "',`fullcontent`='" . mysql_real_escape_string($f) . "',`shortcontent`='" . mysql_real_escape_string($g) . "',`ip`='" . $h . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `sid`='" . $i . "'");

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Sataicpages Master','32','Update','" . $_SESSION['UID'] . "','" . $h . "','" . $i . "')");
        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
    } else {
        $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Page!</h4></div>';
    }
    //$res="UPDATE `static_pages` SET `metatitle`='" . trim(mysql_real_escape_string($a)) . "',`metakeywords`='" . trim(mysql_real_escape_string($b)) . "',`metadescription`='" . trim(mysql_real_escape_string($c)) . "',`banner`='" . $d . "',`image`='" . $e . "',`fullcontent`='" . mysql_real_escape_string($f) . "',`shortcontent`='" . trim(mysql_real_escape_string($g)). "',`ip`='" . $h . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `sid`='" . $i . "'";
    return $res;
}

function getstaticpages($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `static_pages` WHERE `sid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delstaticpages($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Static Pages','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `static_pages` WHERE `sid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addtestimonials($a, $name, $b, $c, $d, $image, $f, $g, $h) {
    if ($h == '') {
        $resa = mysql_query("INSERT INTO `testimonials` (`title`,`name`,`position`,`comments`,`email`,`image`,`status`,`ip`,`updated_by`) VALUES('" . trim(mysql_real_escape_string($a)) . "','" . trim(mysql_real_escape_string($name)) . "','" . trim(mysql_real_escape_string($b)) . "','" . trim(stripslashes(mysql_real_escape_string($c))) . "','" . trim($d) . "','" . trim($image) . "','" . mysql_real_escape_string($f) . "','" . mysql_real_escape_string($g) . "','" . $_SESSION['UID'] . "')");

        $insert_id = mysql_insert_id();

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Testimonials','19','Insert','" . $_SESSION['UID'] . "','" . $g . "','" . $insert_id . "')");
        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
    } else {
        $ress = DB_QUERY("SELECT `tid` FROM `testimonials` WHERE `status`!='2' AND `tid`!='" . $h . "'");
        if ($ress['tid'] != '') {
            $resa = mysql_query("UPDATE `testimonials` SET `title`='" . trim(mysql_real_escape_string($a)) . "',`name`='" . trim(mysql_real_escape_string($name)) . "',`position`='" . trim(mysql_real_escape_string($b)) . "',`comments`='" . trim(stripslashes(mysql_real_escape_string($c))) . "',`email`='" . trim($d) . "',`image`='" . $image . "',`status`='" . $f . "',`ip`='" . $g . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `tid`='" . $h . "'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Testimonial','19','Update','" . $_SESSION['UID'] . "','" . $g . "','" . $h . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        }
    }

    return $res;
}

function gettestimonials($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `testimonials` WHERE `tid`='$b'"));
    $res = $get[$a];
    return $res;
}

function deltestimonials($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Testimonials','19','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `testimonials` WHERE `tid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}
function addimage($title, $image,  $g, $h) {
    if ($h == '') {
        $resa = mysql_query("INSERT INTO `imageupload` (`title`,`image`,`ip`,`updated_by`) VALUES('" . trim(mysql_real_escape_string($title)) . "','" . trim($image) . "','" . mysql_real_escape_string($g) . "','" . $_SESSION['UID'] . "')");

        $insert_id = mysql_insert_id();

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Imageupload','19','Insert','" . $_SESSION['UID'] . "','" . $g . "','" . $insert_id . "')");
        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
    } else {
        $ress = DB_QUERY("SELECT `iid` FROM `imageupload` WHERE  `iid`!='" . $h . "'");
        if ($ress['iid'] != '') {
            $resa = mysql_query("UPDATE `imageupload` SET `title`='" . trim(mysql_real_escape_string($title)) . "',`image`='" . $image . "',`ip`='" . $g . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `iid`='" . $h . "'");
           // echo "UPDATE `imageupload` SET `title`='" . trim(mysql_real_escape_string($title)) . "',`image`='" . $image . "',`ip`='" . $g . "',`updated_by`='" . $_SESSION['UID'] . "' WHERE `iid`='" . $h . "'";
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Imageupload','19','Update','" . $_SESSION['UID'] . "','" . $g . "','" . $h . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        }
    }

    return $res;
}
function getimage($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `imageupload` WHERE `iid`='$b'"));
    $res = $get[$a];
    return $res;
}
function delimages($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Testimonials','19','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `imageupload` WHERE `iid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}
function addbanner($a, $b, $c, $d, $e, $f, $g, $color, $h) {
    if ($h == '') {
        $ress = DB_QUERY("SELECT `bid` FROM `banner` WHERE `link`= '" . $b . "' AND `status`!='2'");
        if ($ress['bid'] == '') {
            $resa = mysql_query("INSERT INTO `banner` (`title`,`link`,`image`,`status`,`fromdate`,`todate`,`ip`,`color`,`update_by`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($f) . "','" . trim($g) . "','" . trim($color) . "','" . $_SESSION['UID'] . "')");
            $insert_id = mysql_insert_id();

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('banner','11','Insert','" . $_SESSION['UID'] . "','" . $c . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Banner Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Banner Link!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `bid` FROM `banner` WHERE `link`='" . $b . "' AND `status`!='2' AND `bid`!='" . $h . "'");

        if ($ress['bid'] == '') {
            $resa = mysql_query("UPDATE `banner` SET `title`='" . trim($a) . "',`link`='" . trim($b) . "',`image`='" . trim($c) . "',`status`='" . trim($d) . "',`fromdate`='" . trim($e) . "',`todate`='" . trim($f) . "',`ip`='" . trim($g) . "',`update_by`='" . $_SESSION['UID'] . "',`color`='" . trim($color) . "' WHERE `bid`='" . trim($h) . "'");
            
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('banner','11','Update','" . $_SESSION['UID'] . "','" . $g . "','" . $h . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4><!--<a href="' . $sitename . 'master/addbanner.htm">Back to Listings Page</a>--></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this Banner Link!</h4><!--<a href="' . $sitename . 'master/addbanner.htm">Try Again</a>--></div>';
        }
    }
    //echo "SELECT `bid` FROM `banner` WHERE `title`='" . $a . "'";

    return $res;
}

function getbanner($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `banner` WHERE `bid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function delbanner($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('banner','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `banner` WHERE `bid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    return $res;
}

function addfaq($category, $question, $answer, $order, $status, $image, $banner, $h) {

    if ($h == '') {

        $resa = mysql_query("INSERT INTO `faq` (`category`,`question`,`answer`,`order`,`status`,`image`,`banner`) VALUES ('" . trim($category) . "','" . trim($question) . "','" . trim($answer) . "','" . trim($order) . "','" . trim($status) . "','" . trim($image) . "','" . trim($banner) . "')");
        $insert_id = mysql_insert_id();

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('faq','11','Insert','" . $_SESSION['UID'] . "','" . $c . "','" . $insert_id . "')");

        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i>Faq Successfully Inserted!</h4></div>';
    } else {

        $resa = mysql_query("UPDATE `faq` SET `category`='" . trim($category) . "',`question`='" . trim($question) . "',`answer`='" . trim($answer) . "',`order`='" . trim($order) . "',`status`='" . trim($status) . "',`image`='" . trim($image) . "',`banner`='" . trim($banner) . "' WHERE `fid`='" . $h . "'");

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('faq','11','Update','" . $_SESSION['UID'] . "','" . $g . "','" . $h . "')");
        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
    }
    return $res;
}

function getfaq($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `faq` WHERE `fid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delfaq($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Faq','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `faq`  WHERE `fid` ='" . $c . "'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    //echo "UPDATE `faq` SET `status`='2' WHERE `fid` ='" . $c . "'";
    return $res;
}

function addfaqcategory($a, $b, $c, $d, $e) {
    if ($e == '') {
        $ress = DB_QUERY("SELECT `fcid` FROM `faqcategory` WHERE `category`='" . trim($a) . "'");

        if ($ress['fcid'] == '') {
            $resa = mysql_query("INSERT INTO `faqcategory` (`category`,`order`,`status`,`ip`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "')");

            $insert_id = mysql_insert_id();

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Faq category','11','Insert','" . $_SESSION['UID'] . "','" . $d . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this FAQ Category!</h4></div>';
        }
    } else if ($e != '') {
        $ress = DB_QUERY("SELECT `fcid` FROM `faqcategory` WHERE `category`='" . trim($a) . "' AND `fcid`!='$e'");
        if ($ress['fcid'] == '') {
            $resa = mysql_query("UPDATE `faqcategory` SET `category`='" . trim($a) . "',`order`='" . trim($b) . "',`status`='" . trim($c) . "' WHERE `fcid`='" . $e . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Faq Category','11','Update','" . $_SESSION['UID'] . "','" . $d . "','" . $e . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-warning"></i> We already have this FAQ Category!</h4></div>';
        }
    }
    return $res;
}

function getfaqcategory($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `faqcategory` WHERE `fcid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delfaqcategory($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Faq category','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `faqcategory`  WHERE `fcid` ='" . $c . "'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4></div>';
    //echo "UPDATE `faq` SET `status`='2' WHERE `fid` ='" . $c . "'";
    return $res;
}

/* payment email and function start */

function addwalletadmin($a, $b, $c) {
    $_SESSION['userid'] = $a;
    $_SESSION['sumoftheamount'] = $b;
    if ($_SESSION['adminlastinsertid'] == '') {
        mysql_query("UPDATE `premium_ad` SET `status`='Processing' WHERE `pid` IN($a)");

        $setses = mysql_fetch_array(mysql_query("SELECT * FROM `agent` WHERE `agent_id`='" . $_SESSION['UIDD'] . "'"));
        $_SESSION['adminlastinsertid'] = $setses['aid'];
    }
    header("location:" . $sitename . "paynow/");
    exit;
    $res.=$_SESSION['adminlastinsertid'];
    return $res;
}

function mailfailadmin($a, $b, $c, $d, $e) {
    if ($a != '') {
        $ress = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $e . "'");
        $res = DB_QUERY("SELECT * FROM `wallet` WHERE `cusid`='" . $e . "'");
        $agentres = DB_QUERY("SELECT * FROM `agent` WHERE `agent_id`='" . $res['agent_id'] . "'");
        $from = getprofile('recoveryemail', '1');
        $to = $agentres['emailid'];

        // $to="itsolusenz1@gmail.com";
        $subject = "NBAYSMART - Your transaction with us on " . date('d-m-Y', strtotime(getwallet('date', $res['wid']))) . " is failed";
        $message = '
            <table width="100%" height="100%" style="background:#FFFFF;">
                <tr>
                    <td align="center" valign="middle">
                        <table width="700" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                            <tr>
                                <td align="left" valign="top" colspan="3">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                        <tr>
                                            <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                <img src="' . WEB_ROOT . 'images/logo3.png" alt="NBAYSMART" border="0" height="70" /> 
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td align="left" valign="top" colspan="3">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="3" style="padding:10px;">
                                    Dear ' . $agentres['firstname'] . ' ' . $agentres['lastname'] . ',
                                    <br/><br>
                                    <p style="text-indent:50px;">Your Transaction was failed your amount <b>' . getwallet('total_amount', $res['wid']) . '</b> for Order Number <b>' . getwallet('order_id', $res['wid']) . '</b> ,Please retry your transaction.</p>
                                    <br/><br>
                                </td>
                            </tr>
                            <tr>
                                <td align="left" valign="top" colspan="3" style="padding:10px;">
                                    <h4>Billing Details : </h4>
                                    <br />' . getcustomer('firstname', getwallet('cusid', $res['wid'])) . '<br />' . getcustomer('address1', getwallet('cusid', $res['wid'])) . '<br />' . getcustomer('address2', getwallet('cusid', $res['wid'])) . '<br />' . getcustomer('city', getwallet('cusid', $res['wid'])) . '<br />' . getcustomer('state', getwallet('cusid', $res['wid'])) . '-' . getcustomer('postcode', getwallet('cusid', $res['wid'])) . '<br /><br /><br />
                                        <table width="100%" cellpadding="10" cellspacing="2" style="border:none;">
                                        <tr style="border-bottom:2px solid #F91261;">
                                            <th width="5%" align="center">S.No</th>
                                            <th width="15%" align="center">Date</th>
                                            <th width="60%" align="center">Details</th>
                                            <th width="20%" style="text-align:right;">Amount (INR)</th>
                                        </tr>
                                        <tr style="border-bottom:1px solid #999999;">
                                            <td align="center">1<br /><br /></td>
                                            <td align="left">' . date('d-M-Y H:i a', strtotime(getwallet('trans_date', $res['wid']))) . '</td>
                                            <td>Wallet Payment - Order Number : (' . getwallet('order_id', $res['wid']) . ')</td>
                                            <td align="right">' . getwallet('amount', $res['wid']) . '</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" align="right">Tax : </td>
                                            <td align="right">' . getwallet('tax_amount', $res['wid']) . '</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" align="right">Total : </td>
                                            <td align="right">' . getwallet('total_amount', $res['wid']) . '</td>
                                        </tr>
                                    </table>
                                    
                                    Best Wishes from NBAYSMART
                                </td>
                            </tr>
                            <tr>
                                <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>';

//        $headers = "MIME-Version: 1.0 \n";
//        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//        $headers .= "From: " . $from . " \r\n ";
//       
//        mail($to, $subject, $message, $headers);
        sendgridmail($to, $message, $subject, '', '');
    }
}

function mailsuccadmin($a, $b, $c, $d) {
    if ($a != '') {

        $ress = DB_QUERY("SELECT * FROM `agent` where `agent_id`='" . $a . "'");

        //$res=DB_QUERY("SELECT * FROM `premium_ad` where `agent_id`='".$b."' and `pid`='".$c."'");
        //echo "SELECT * FROM `premium_ad` where `agent_id`='".$b."' and `pid`='".$c."'";
        $from = getprofile('recoveryemail', '1');
        $to = $ress['email'];
        // $to="itsolusenz1@gmail.com";
        $subject = "Payment Trancation added Success";
        $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $ress['title'] . '.' . $ress['firstname'] . ' ' . $ress['lastname'] . ',<br/><br>'
                . '<p style="text-indent:50px;">We have Successfully received your amount ' . $d . ' Thanks for Nbaysmart</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//        $headers = "MIME-Version: 1.0 \n";
//        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//        $headers .= "From: " . $from . " \r\n ";
//
//        mail($to, $subject, $message, $headers);
        sendgridmail($to, $message, $subject, '', '');
    }
}

function mailcanceladmin($a, $b, $c, $d) {
    if ($a != '') {

        $ress = DB_QUERY("SELECT * FROM `agent` where `agent_id`='" . $a . "'");

        //$res=DB_QUERY("SELECT * FROM `premium_ad` where `agent_id`='".$b."' and `pid`='".$c."'");
        //echo "SELECT * FROM `premium_ad` where `agent_id`='".$b."' and `pid`='".$c."'";
        $from = getprofile('recoveryemail', '1');
        $to = $ress['email'];
        // $to="itsolusenz1@gmail.com";
        $subject = "Payment Trancation canceled";
        $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $ress['title'] . '.' . $ress['firstname'] . ' ' . $ress['lastname'] . ',<br/><br>'
                . '<p style="text-indent:50px;">We have Canceled your amount ' . $d . ' </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//        $headers = "MIME-Version: 1.0 \n";
//        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//        $headers .= "From: " . $from . " \r\n ";
//
//        mail($to, $subject, $message, $headers);
        sendgridmail($to, $message, $subject, '', '');
    }
}

/* payment email and function end */

function Coundays($from, $to) {

    $from = date('d-m-Y', strtotime($from));
    $to = date('d-m-Y', strtotime($to));
    $cnt = 0;
    $nodays = 0;
    $nodays = (strtotime($to) - strtotime($from)) / (60 * 60 * 24); //it will count no. of days
    $nodays = $nodays + 1;
    for ($i = 0; $i < $nodays; $i++) {
        $p = 0;
        list($d, $m, $y) = explode("-", $from);
        $datetime = strtotime("$d-$m-$y");
        $nextday = date('d-m-Y', strtotime("+1 day", $datetime));  //this will add one day in from date (from date + 1)
        if ($i == 0) {
            $p = date('w', strtotime($from));
        } else {
            $p = date('w', strtotime($nextday));
        }
        $cnt++;
        $from = $nextday;
        $p++;
    }
    return $cnt;
}

function ad_approve_mail($adid) {
    $adsid = $adid * 776 + 5;
    
    $adlink= WEB_ROOT . 'viewad-' . preg_replace('/-{2,}/', '-',str_replace("@","",str_replace('&','and',str_replace(" ", "-",str_replace(",","",str_replace("%", "", strtolower(preg_replace('/[^A-Za-z0-9& \ -]/', "", getadvertis('adtitle', $adid))))))))) . '/' . '?view=' . $adsid . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $adid)));
    $subject = "Advertisement on Live - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement on Live</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('title', getadvertis('customerid', $adid)) . '.' . getcustomer('firstname', getadvertis('customerid', $adid)) . ' ' . getcustomer('lastname', getadvertis('customerid', $adid)) . '</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> </p>
                                                 <p> Your advertisement is Live now on Nbaysmart.com.</p>
                                                <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $adid) . '</strong></p>
                                                <p><strong> Your Advertisement Link : <a style="color:#00CAEC" href="' . $adlink . '">'.$adlink.'</a></strong></p>';
                                                  if((getadvertis('adtype',$adid))==2){
                                                   ' <p>Your advertisement will be experies on ' . date('d-m-Y', strtotime(getadvertis('expdate', $adid))) . ' </p>';
                                                    } 
                                                '<p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers .= "From: " . $from . " \r\n ";
//    mail($to, $subject, $message, $headers);
    
   sendgridmail($to, $message, $subject, '', '');
      //echo $to,$message,$subject;
}

function ad_disapprove_mail($chksh) {
    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $chksh)));
    $subject = "Advertisement Disapproved - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Disapproved</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('title', getadvertis('customerid', $chksh)) . '.' . getcustomer('firstname', getadvertis('customerid', $chksh)) . ' ' . getcustomer('lastname', getadvertis('customerid', $chksh)) . '</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                 <p>Your advertisement <b> Disapproved </b> by admin.</p>
                                                  <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $chksh) . '</strong></p>
                                               <p>Please contact admin to approved your advertisement.</p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers .= "From: " . $from . " \r\n ";
//    mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');
}

function ad_mail_insert($insert_id) {
    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $insert_id)));
    $subject = "Advertisement Confirmation - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Posted </span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('firstname', getadvertis('customerid', $insert_id)) . ' ' . getcustomer('lastname', getadvertis('customerid', $insert_id)) . '</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                 <p>Your advertisement will be approved by admin in maximum of 24 hours.</p>
                                                <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $insert_id) . '</strong></p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers .= "From: " . $from . " \r\n ";
//
//    mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');
}

function ad_mail_dis($r) {

    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $r)));
    $subject = "Advertisement Disapproved - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Disapproved</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('firstname', getadvertis('customerid', $r)) . ' ' . getcustomer('lastname', getadvertis('customerid', $r)) . '</strong></p>
                                                 <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                 <p>Your advertisement <b> Disapproved </b> by admin.please check whether the given details are correct or appropriate.</p>
                                                 <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $r) . '</strong></p>
                                               <p>Please contact admin to approved your advertisement.</p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers .= "From: " . $from . " \r\n ";
//
//    mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');
}

function ad_mail_update($r) {
    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $r)));
    $subject = "Advertisement Update Conformation - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Updated </span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('firstname', getadvertis('customerid', $r)) . ' ' . getcustomer('lastname', getadvertis('customerid', $r)) . '</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                 <p>Your updated advertisement will be approved by admin within 2 to 4 hours.</p>
                                                <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $r) . '</strong></p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

    sendgridmail($to, $message, $subject, '', '');
    // echo $to, $subject, $message, $headers;
    // exit;
    //return $message;
}
function ad_mail_cus($r) {
    $from = getprofile('recoveryemail', '1');
    $to = trim(getcustomer('emailid', getadvertis('customerid', $r)));
    $subject = "Advertisement Update Conformation - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Updated </span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . getcustomer('firstname', getadvertis('customerid', $r)) .'</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                 <p>Your Posted advertisement will be approved by admin within 2 to 4 hours.</p>
                                                <p><strong>Your Advertisement_id : ' . getadvertis('advertising_id', $r) . '</strong></p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

    sendgridmail($to, $message, $subject, '', '');
    // echo $to, $subject, $message, $headers;
    // exit;
    //return $message;
}
function sendlogindetail($FirstName,$EmailID,$Password) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($EmailID);
    $subject = "Verify your account - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Verify Your Account</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear User,</strong></p>
                                                <p>Welcome to the Nbaysmart.com. We are delighted to have you on board!</p>
                                                <p>Nbaysmart makes your Connections more Comfort</p>
                                                <p>&nbsp;</p>
                                                
                                                <p>User Name: ' . $EmailID . '</p>
                                                <p>Password: ' . $Password . '</p>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

   
    sendgridmail($to, $message, $subject, '', '');
}
?>