<?php

function prosendd($a,$b,$c,$d)
{  

    $message='hi';
 
return $message;
 
}
function resend($a,$ip) {
      //global $db;
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
    	 
    	//nbays_resent=$db->prepare("SELECT * FROM `smslog` WHERE `sid`=?");
    	//$nbays_resent->execute(array($c));
    	$nbays_resent_val=DB_QUERY("SELECT * FROM `smslog` WHERE `sid`='".$c."'");
    	resendsms('NBAYSI', $nbays_resent_val['message'], $nbays_resent_val['number'], $ip, '1',$nbays_resent_val['sid']);
    	
    	//print_r($nbays_resent_val['message']);
    	//exit;
    }
   // $res = '<div class="alert alert-success alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i> Successfully Resent!</h4></div>';
  //  return $res;
}
function resendsms($senderid, $message, $noumbers, $ip, $codevalue,$sid) {
    global $db;
    $getmessage = $message;
    $getmessagecount = strlen($getmessage) + 1;
    $totalcount = $getmessagecount;
    $totalmessage = $getmessage;

    $mob_num = explode(",", $noumbers);
    $sms_msgv = trim($totalmessage);
    $sms_cnt = ceil(strlen($sms_msgv) / 160);

    $sms_sender_id = $senderid;

    foreach ($mob_num as $val) {
        if ($val != '') {

            $rsp = "http://smst.itsolusenz.com/api/sendmsg.php";
            //unicode        
            if ($codevalue == '1') {
                $styp = 'normal';
            } elseif ($codevalue == '2') {
                $styp = 'unicode';
            } else {
                $styp = 'normal';
            }

            $params = array("user" => 'Nbaysmart', "pass" => 'nbaysmart', "phone" => trim($val), "text" => $sms_msgv, "priority" => 'ndnd', "stype" => $styp, "sender" => "NSMART");

            $ch = curl_init();

            if (count($params) > 0) {
                $query = http_build_query($params);
                curl_setopt($ch, CURLOPT_URL, "$rsp?$query");
            } else {
                curl_setopt($ch, CURLOPT_URL, $rsp);
            }

            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            $response = curl_exec($ch);
            $ress .= $rsp . '?' . $query . '?' . $response;
            //$sms_msgv=mysql_real_escape_string($sms_msgv);
           $ress= mysql_query("UPDATE `smslog` SET `uid`='".$_SESSION['UID']."',`cusid`='".$_SESSION['UID']."',`date`=NOW(),`messagecount`='".$sms_cnt."',`remainsmscount`='',`unicode`='',`delivered`='',`scheduledsms`='',`promotional`='0',`transactional`='1',`groupsms`='0',`ip`='".$ip."',`number`='".$val."',`message`='".$sma_msgv."' WHERE `sid`='".$sid."'");
          // $ress->execute(array($_SESSION['UID'],$_SESSION['UID'],$sms_cnt,'','','','',0,1,0,$ip,$val,$sms_msgv,$sid));

            $iid = $sid;

            //mysql_query("UPDATE `noti_customer` SET `remainsmscount`='" . (getcustomer('remainsmscount', $_SESSION['UID']) - $sms_cnt) . "' WHERE `id`='" . $_SESSION['UID'] . "'");

            if ($response != '') {
                if ($response == 'No Sufficient Credits') {
                   $res1=mysql_query("UPDATE `smslog` SET `serverresponse`='".$response."' WHERE `sid`='".$iid."'");
                   //$res1->execute(array($response,$iid));
                    $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i>SMS count 0 please recharge now. thank you</h4></div>';

                    return $res;
                    break;
                } elseif ($response == 'Sender ID Does not Exist or Pending or Route Invalid!') {
                   $res1=mysql_query("UPDATE `smslog` SET `serverresponse`='".$response."' WHERE `sid`='".$iid."'");
                  //$res1->execute(array($response,$iid));
                    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i>' . $response . '</h4></div>';
                    return $res;
                    break;
                } elseif ($response == 'Username/Password Incorrect or Account Deactivated') {
                   //$res1= $db->prepare("UPDATE `smslog` SET `serverresponse`=? WHERE `sid`=?");
                     $res1=mysql_query("UPDATE `smslog` SET `serverresponse`='".$response."' WHERE `sid`='".$iid."'");
                   //$res1->execute(array($response,$iid));
                    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i>' . $response . '</h4></div>';
                    return $res;
                    break;
                } else {
                  //$res1= $db->prepare("UPDATE `smslog` SET `serverresponse`=?,`delivered`=? WHERE `sid`=?");
                     $res1=mysql_query("UPDATE `smslog` SET `serverresponse`='".$response."',`delivered`='1' WHERE `sid`='".$iid."'");
                 // $res1->execute(array($response,1,$iid));
                    $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i>SMS Sent Successfully... </h4></div>';
                }
            } else {
              $res1=mysql_query("UPDATE `smslog` SET `serverresponse`='SERVER Response Error' WHERE `sid`='".$iid."'");
              //$res1->execute(array('SERVER Response Error',$iid));
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button><h4><i class="icon fa fa-check"></i>Could not send the sms... SERVER ERROR</h4></div>';
                //return $res;
                // break;
            }
        }
    }
    return $res;
    // return $res;
}
function contactform($a, $b, $c, $d, $e)
{
    $resa = mysql_query("INSERT INTO `contact_form` (`nAme`,`pHone`,`eMail`,`cOmments`,`IP`) VALUES ('" . $a . "','" . $b . "','" . $c . "','" . $d . "','" . $e . "')");
    $insert_id = mysql_insert_id();
    $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Contact Master','26','Insert','','" . $e . "','" . $insert_id . "')");
    $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Your comments successfully submitted, we will get back to you within 48 hours.</span></div>';

    $sqladmin = DB_QUERY("SELECT * FROM `manageprofile` WHERE `pid`='1'");

    $to = $sqladmin['recoveryemail'];
    $subject = "Contact From  " . $a;

    $message = '<table width="600" border="0" cellspacing="0" cellpadding="10" style="border:10px solid #01e060; background:#333333; color:#FFFFFF;">
            <tr>
                <td align="left" valign="top" colspan="3">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
                        <tr>
                            <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="100" /> 
                            </td>
                            <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Contact Form</span></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td align="left" valign="top" colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td width="30%" align="right" valign="top"><strong>Name</strong></td>
                <td width="5%" align="center">:</td>
                <td width="65%" align="left">' . $a . '</td>
            </tr>
            <tr>
                <td width="30%" align="right" valign="top"><strong>E-mail Address</strong></td>
                <td width="5%" align="center">:</td>
                <td width="65%" align="left">' . $b . '</td>
            </tr>
            <tr>
                <td width="30%" align="right" valign="top"><strong>Phone Number</strong></td>
                <td width="5%" align="center">:</td>
                <td width="65%" align="left">' . $c . '</td>
            </tr>
            
            <tr>
                <td width="30%" align="right" valign="top"><strong>Comments</strong></td>
                <td width="5%" align="center">:</td>
                <td width="65%" align="left">' . $d . '</td>
            </tr>
            
            <tr>
                <td align="left" valign="top" colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td height="26" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; font-weight:normal; color:#000;" colspan="3">&copy; ' . date('Y') . ' NBAYSMART. All Rights Reserved.&nbsp;</td>
            </tr>
        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//
//    $headers .= "From: " . $_REQUEST['email'] . " \r\n ";
//
//    mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');

//echo $to, $subject, $message, $headers;
//exit;

    return $res;
}

function getcontactform($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `contact_form` WHERE `cid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delcontactform($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Contact List','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `contact_form` WHERE `cid` ='" . $c . "' ");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!!</h4></div>';
    return $res;
}

/* Signin start */

function signupverifyfunc($loginemail, $loginpassword, $actual_link) {

    if (($loginemail == '') || ($loginpassword == '')) {
        $res = "Login Credentials are Empty";
    } else {
        $ress = mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE (`emailid`='" . $loginemail . "')OR(`phoneno`='" . $loginemail . "')"));
        if ($ress['cusid'] != '') {
            if ($ress['status'] == '1') {
                if ($ress['password'] == trim($loginpassword)) {
                    $res = "Hurray! You will redirect soon";
                    $_SESSION['FUID'] = $ress['cusid'];
                    @extract($ress);
                    if ($cusid != '') {
                        $myquery = mysql_query("INSERT INTO `userloginhty` (`email`,`ip`,`datetime`,`status`) VALUES ('" . $emailid . "','" . $ip . "','" . date('Y-m-d H:i:s') . "','" . $ress['status'] . "')");
                        $_SESSION['HID'] = mysql_insert_id();
                        if ($actual_link != '') {
                            header("location:$actual_link");
                            exit;
                        } else if ($_SESSION['myrvid'] != '') {
                            header("location:" . WEB_ROOT . "company-review/" . $_SESSION['myrvid'] . "/");
                        } else {
                            header("location:" . WEB_ROOT . "my_dashboard/");
                            exit;
                        }
                    }
                } else {
                    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span style="color:#FF0000;"><i class="icon fa fa-close"></i> Password was incorrect </span></div>';
                }
            } else {
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span style="color:#FF0000;"><i class="icon fa fa-close"></i> Your account in Deactive mode... Please contact Administrator  </span></div>';
            }
        } else {

            if ($actual_link == '') {
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span style="color:#FF0000;"><i class="icon fa fa-close"></i> Login Credentials was Incorrect </span></div>';
            } else {
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span style="color:#FF0000;"><i class="icon fa fa-close"></i> Login Credentials was Incorrect </span></div>';
                header("location:" . WEB_ROOT . "signup/?invalid=login");
            }
        }
    }
    return $res;
}

/* Signin verify end */

function otpverify($a, $b) {

    if ($a != '') {
        $ress = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $_SESSION['VUID'] . "'");
        if ($a == $ress['otp']) {
            if (($ress['cusid'] != '') && ($ress['signupwith'] == 'email')) {
                $resa = DB("UPDATE `customer` SET `emailverification`='1',`status`='1' WHERE `cusid`='" . $_SESSION['VUID'] . "'");
                $resad=DB_QUERY("SELECT * FROM `create_ads` where `customerid`='".$_SESSION['VUID']."'");
                if($resad['customerid']!='')
                {
                $res=DB("UPDATE `create_ads` SET `customer_verified`='1' where `customerid`='".$_SESSION['VUID']."'");
                ad_mail_cus($res['customerid']);
                }
                
                $_SESSION['FUID'] = $_SESSION['VUID'];
                  $ress1 = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
                   $ip = $_SERVER['REMOTE_ADDR'];
                sendcustomer($ress1['firstname'],$ress1['emailid'],$ress1['phoneno'],$ress1['password'],$ip);
                header("location:" . WEB_ROOT . "myaccount/");
                $res = '<div class="alert alert-success alert-dismissible"><i class="icon fa fa-check"></i> Email verified Successfully</span></div>';
            } elseif (($ress['cusid'] != '') && ($ress['signupwith'] == 'mobile')) {
                $resa = DB("UPDATE `customer` SET `phonenoverification`='1',`status`='1' WHERE `cusid`='" . $_SESSION['VUID'] . "'");
                  $resad=DB_QUERY("SELECT * FROM `create_ads` where `customerid`='".$_SESSION['VUID']."'");
                if($resad['customerid']!='')
                {
                $res=DB("UPDATE `create_ads` SET `customer_verified`='1' where `customerid`='".$_SESSION['VUID']."'");
                $message = 'Hi ' . getcustomer('firstname', getadvertis('customerid', $res['customerid'])) . ',Your Posted advertisement will be approved by admin in maximum of 24 hours. Your Advertisement_id : ' . getadvertis('advertising_id', $res['customerid']) . ' Thank you';
                   $contactno= getcustomer('phoneno', getadvertis('customerid', $res['customerid']));
                  $ip = $_SERVER['REMOTE_ADDR'];
                    sendsms('NBAYSI', $message, $contactno, $ip, '1');
                     
                }
                $_SESSION['FUID'] = $_SESSION['VUID'];
                 $ress1 = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
                 $ip = $_SERVER['REMOTE_ADDR'];
                sendcustomer($ress1['firstname'],$ress1['emailid'],$ress1['phoneno'],$ress1['password'],$ip);
                header("location:" . WEB_ROOT . "myaccount/");
                $res = '<div class="alert alert-success alert-dismissible"><i class="icon fa fa-check"></i> Phonenumber verified Successfully</span></div>';
            }
        } else {
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-close"></i>Please Enter Correct OTP</h4></div>';
            //$res = '<div class="alert alert-danger alert-dismissible"><i class="icon fa fa-close"></i> Please Enter Correct OTP </span></div>';
        }
    }
    return $res;
}

/* Newsletter subcribe start */

function fusernewssubmit($a, $b) {
    if ($a != '') {
        $ress = DB_QUERY("SELECT * FROM `newslettersubscribe` WHERE `email`='" . $a . "'");
        if ($ress['nid'] == '') {
            $resa = mysql_query("INSERT INTO `newslettersubscribe` (`email`,`ip`) VALUES ('" . trim($a) . "','" . trim($b) . "')");
            $insert_id = mysql_insert_id();

            $from = getprofile('recoveryemail', '1');
            $to = trim($a);
            $subject = "Newsletter Subscribe - Nbaysmart";
            $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Newsletter Subscribe</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . $a . '</strong></p>
                                                <p>Welcome to the <b> Nbaysmart.com</b> We are delighted to have you on board!</p>
                                                <p>Nbaysmart makes your Connections more Comfort.</p>
                                                <p>Thanks for your Newsletter Subscribe.</p>
                                                <p>You will get a lot of infomation and makes you confort with our products.</p>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                                <a href="' . WEB_ROOT . '"> Nbaysmart</a>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers = "MIME-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";
//
//            mail($to, $subject, $message, $headers);
            sendgridmail($to, $message, $subject, '', '');
            //echo $to, $subject, $message, $headers;
            //exit;
            //return $message;
            header("location:" . $_REQUEST['URI'] . "?nsuc#newsletter");
            exit;
            echo '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i> You have subscribed successfully.</div>';
        } else {
            header("location:" . $_REQUEST['URI'] . "?nfail#newsletter");
            exit;
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-close"></i> You have already Subscribed.</div>';
        }
    }
    return $res;
}

/* Newsletter subcribe end */

/* User signup verification function start */

function fusersignupverify($a, $b, $c, $d, $e) {
    if ($b != '') {
        $v = 'email';
        $ress = DB_QUERY("SELECT `cusid`,`emailid`,`phoneno`,`emailverification` FROM `customer` WHERE `emailid`='" . $b . "'");
        if ($ress['cusid'] != '') {
            if (($ress['emailverification'] == 0) && ($ress['emailid'] != '')) {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/notverified/");
                exit;
            } elseif ($ress['emailid'] != '') {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/exist/");
                exit;
            }
        }
    } elseif ($c != '') {
        $v = 'mobile';
        $ress = DB_QUERY("SELECT `cusid`,`phoneno`,`emailid`,`phonenoverification` FROM `customer` WHERE `phoneno`='" . $c . "'");
        if ($ress['cusid'] != '') {
            if (($ress['phonenoverification'] == 0) && ($ress['phoneno'] != '')) {
                $_SESSION['regtype'] = $v;
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/notverified/");
                exit;
            } elseif ($ress['phoneno'] != '') {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/exist/");
                exit;
            }
        }
    }
    if ($ress['cusid'] == '') {
        $num = '';
        for ($i = 0; $i < 6; $i++)
            $num .= mt_rand(0, 9);
        $otp = $num;

        $resa = mysql_query("INSERT INTO `customer` (`firstname`,`emailid`,`phoneno`,`password`,`ip`,`status`,`updatedtype`,`otp`,`signupwith`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','0','1','" . trim($otp) . "','" . $v . "')");


        $insert_id = mysql_insert_id();

        $customer_id = 'NMC' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);

        $resa = mysql_query("UPDATE `customer` SET `customerid`='" . $customer_id . "' WHERE `cusid`='" . $insert_id . "'");

        $_SESSION['CUSID'] = $insert_id;
        $_SESSION['regtype'] = $v;

        if ($b != '') {
            $_SESSION['VUID'] = $insert_id;
            verificationmail($b, $otp, $_SESSION['VUID']);
            header("location:" . WEB_ROOT . "signup/step2/");
            exit;
        } elseif ($c != '') {
            $message = 'Hi ' . $a . ', Your one time verification code for NBAYSMART is ' . $otp . '. Thank you';
            sendsms('NBAYSI', $message, $c, $e, '1');
            $_SESSION['VUID'] = $insert_id;
            header("location:" . WEB_ROOT . "signup/step2/");
            exit;
        }
    }

    return $res;
}

function sendsms($senderid, $message, $noumbers, $ip, $codevalue) {
    $getmessage = $message;
    $getmessagecount = strlen($getmessage) + 1;
    $totalcount = $getmessagecount;
    $totalmessage = $getmessage;

    $mob_num = explode(",", $noumbers);
    $sms_msgv = trim($totalmessage);
    $sms_cnt = ceil(strlen($sms_msgv) / 160);

    $sms_sender_id = $senderid;

    foreach ($mob_num as $val) {
        if ($val != '') {

            $rsp = "http://smst.itsolusenz.com/api/sendmsg.php";
            //unicode        
            if ($codevalue == '1') {
                $styp = 'normal';
            } elseif ($codevalue == '2') {
                $styp = 'unicode';
            } else {
                $styp = 'normal';
            }

            $params = array("user" => 'Nbaysmart', "pass" => 'nbaysmart', "phone" => trim($val), "text" => $sms_msgv, "priority" => 'ndnd', "stype" => $styp, "sender" => "NSMART");

            $ch = curl_init();

            if (count($params) > 0) {
                $query = http_build_query($params);
                curl_setopt($ch, CURLOPT_URL, "$rsp?$query");
            } else {
                curl_setopt($ch, CURLOPT_URL, $rsp);
            }

            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            $response = curl_exec($ch);
            $ress .= $rsp . '?' . $query . '?' . $response;
            mysql_query("INSERT INTO `smslog` SET `uid`='" . $_SESSION['UID'] . "',`cusid`='" . $_SESSION['UID'] . "',`date`=NOW(),`messagecount`='" . $sms_cnt . "',`remainsmscount`='',`unicode`='',`delivered`='',`scheduledsms`='',`promotional`='0',`transactional`='1',`groupsms`='0',`ip`='" . $ip . "',`number`='" . $val . "',`message`='" . mysql_real_escape_string($sms_msgv) . "'");

            $iid = mysql_insert_id();

            //mysql_query("UPDATE `noti_customer` SET `remainsmscount`='" . (getcustomer('remainsmscount', $_SESSION['UID']) - $sms_cnt) . "' WHERE `id`='" . $_SESSION['UID'] . "'");

            if ($response != '') {
                if ($response == 'No Sufficient Credits') {
                    mysql_query("UPDATE `smslog` SET `serverresponse`='" . $response . "' WHERE `sid`='" . $iid . "'");
                    $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>SMS count 0 please recharge now. thank you</h4></div>';

                    return $res;
                    break;
                } elseif ($response == 'Sender ID Does not Exist or Pending or Route Invalid!') {
                    mysql_query("UPDATE `smslog` SET `serverresponse`='" . $response . "' WHERE `sid`='" . $iid . "'");
                    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>' . $response . '</h4></div>';
                    return $res;
                    break;
                } elseif ($response == 'Username/Password Incorrect or Account Deactivated') {
                    mysql_query("UPDATE `smslog` SET `serverresponse`='" . $response . "' WHERE `sid`='" . $iid . "'");
                    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>' . $response . '</h4></div>';
                    return $res;
                    break;
                } else {
                    mysql_query("UPDATE `smslog` SET `serverresponse`='" . $response . "',`delivered`='1' WHERE `sid`='" . $iid . "'");
                    $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>SMS Sent Successfully... </h4></div>';
                }
            } else {
                mysql_query("UPDATE `smslog` SET `serverresponse`='SERVER Response Error' WHERE `sid`='" . $iid . "'");
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>Could not send the sms... SERVER ERROR</h4></div>';
                //return $res;
                // break;
            }
        }
    }
    return $res;
    // return $res;
}
function verificationmailprofile($b, $otp, $s) {
    $active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($b);
    $subject = "Verify your account - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Verify Your Email</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear User,</strong></p>
                                                <p>Welcome to the Nbaysmart.com. We are delighted to have you on board!</p>
                                                <p>We are here to assist you in any possible way as we can. Have a pleasent online experience.</p>
                                                <p>&nbsp;</p>
                                                <p>' . $otp . '</p>
                                                <p>&nbsp;</p>
                                                <p>Click above link to Verify Your Email. </p>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';


    sendgridmail($to, $message, $subject, '', '');
}
function verificationmail($b, $otp, $s) {
    $active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($b);
    $subject = "Verify your account - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Verify Your Account</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear User,</strong></p>
                                                <p>Welcome to the Nbaysmart.com. We are delighted to have you on board!</p>
                                                <p>We are here to assist you in any possible way as we can. Have a pleasent online experience.</p>
                                                <p>&nbsp;</p>
                                                <p><a style="color:#00CAEC" href="' . WEB_ROOT . 'emailverification/' . base64_encode($_SESSION['CUSID']) . '/' . md5($_SESSION['VUID']) . '/">' . WEB_ROOT . 'emailverification/' . base64_encode($_SESSION['CUSID']) . '/' . md5($_SESSION['VUID']) . '/</a></p>
												<p>( or )</p>
												<p>' . $otp . '</p>
                                                <p>&nbsp;</p>
                                                <p>Click above link to Verify Your Account. </p>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';


    sendgridmail($to, $message, $subject, '', '');
}

function verificationmail1($b, $s) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($b);
    $subject = "Verify your account - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Verify Your Account</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear User,</strong></p>
                                                <p>Welcome to the Nbaysmart.com. We are delighted to have you on board!</p>
                                                <p>Nbaysmart makes your Connections more Comfort</p>
                                                <p>&nbsp;</p>
                                                
                                                <p>User Name: ' . getcustomer('emailid', $s) . '</p>
                                                <p>Password: ' . getcustomer('password', $s) . '</p>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';


    sendgridmail($to, $message, $subject, '', '');
}

function verificationmailresend($b, $otp, $s) {
    $active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($b);
    $subject = "Verify your account - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Verify Your Account</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear User,</strong></p>
                                                <p>Welcome to the Nbaysmart.com. We are delighted to have you on board!</p>
                                                <p>Nbaysmart makes your Connections more Comfort</p>
                                                <p>&nbsp;</p>
                                                <p><a style="color:#00CAEC" href="' . WEB_ROOT . 'emailverification/' . base64_encode($_SESSION['CUSID']) . '/' . md5($_SESSION['VUID']) . '/">' . WEB_ROOT . 'emailverification/' . base64_encode($_SESSION['CUSID']) . '/' . md5($_SESSION['VUID']) . '/</a></p>
												<p>( or )</p>
												<p>' . $otp . '</p>
                                                <p>&nbsp;</p>
                                                <p>Click above link to Verify Your Account. </p>
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';


    sendgridmail($to, $message, $subject, '', '');
}

/* User signup verification function end */

function fusersignup($a, $b, $c, $d, $e, $f, $g) {
    if ($c != '') {
//        $ress = DB_QUERY("SELECT `cusid` FROM `customer` WHERE `emailid`='" . $c . "'");
//
//        $resa = mysql_query("UPDATE `customer` SET `firstname`='" . trim($a) . "',`lastname`='" . trim($b) . "',`agentcode`='" . trim($d) . "',`phoneno`='" . trim($e) . "',`password`='" . trim($f) . "',`ip`='" . trim($g) . "',`status`='1',`updatedtype`='1',`updatedid`='" . $ress['cusid'] . "' WHERE `emailid`='" . trim($c) . "'");
//        $_SESSION['FUID'] = $ress['cusid'];
//
//        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('signup','18','Update','" . $_SESSION['FUID'] . "','" . $g . "','" . $insert_id . "')");

        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i>Account Created Successfully!</div>';
        $from = getprofile('recoveryemail', '1');
        $to = trim($c);
        // $to="itsolusenz1@gmail.com";
        $subject = "Welcome to Nbaysmart";
        $message = '<table width="100%" height="100%" style="background:#FFFFF;">
            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Your Account Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear ' . $a . ',</strong></p><br/>
                                                <p>Welcome to <strong>Nbaysmart</strong></p><br/>
            <p>Nbaysmart is an online platform which provides opportunity for businesses to connect with other businesses and Customers.</p><br/>
            <p>They help in exchange of Information, Services and Products among businesses in a secure portal through which they can conduct and improve their own business.</p><br/>
            <p>Nbaysmart provides numerous business opportunities like:</p><br/>
            <ul>
                <li>Business to Business </li>
                <li>Business to Customer </li>
                <li>Wholesale to Retailer</li>
            </ul>
            <p>&nbsp;</p><br/>
                                                <p>We provide businesses the necessary exposure they need to thrive their business forward and improve their profits. You can explore new business opportunity and make ideal business connection to improve your business.</p><br/>
            <table width="60%" cellpadding="5" cellspacing="5" bgcolor="#b3945d" align="center">
                <tr>
                    <th colspan="2" style="font-size:14px; font-weight:bold;">To log in, just enter your e-mail address and password.</th>
                </tr>
                <tr>
                    <td bgcolor="#eec070" align="center" width="30%" style="font-size:13px; font-weight:bold;">Login Id:</td>
                    <td bgcolor="#eec070" align="center" style="font-size:13px; font-weight:bold;">' . $c . '</td>
                </tr>
                <tr>
                    <td bgcolor="#eec070" align="center" style="font-size:13px; font-weight:bold;">Password:</td>
                    <td bgcolor="#eec070" align="center" style="font-size:13px; font-weight:bold;">' . $f . '</td>
                </tr>
            </table>

            <p>&nbsp;</p>
          
            <p>Once you log in to your account, you will be able to do the following: </p><br/>
            <ul>
                <li>You can change account details or update your information</li>
                <li>Navigate through our list of businesses and Wholesale</li>
                <li>Check your listing status</li>
                <li>Check your Order History and Order Status</li>
                <li>Change password</li>
                
            </ul><br/>
          
            <p>For further inquiry regarding your account or services, please feel free to contact us on nbaysmart@gmail.com</p><br/>
            <p align="center">Thank You,</p>
            <p align="right">Best Regards,</p>
            <p align="right">NbaySmart Team</p>
        </td>
                                     
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
</table>';

        sendgridmail($to, $message, $subject, '', '');


        $subject1 = "New User Register with Nbaysmart";
        $message2 = '
<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="2">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">New User Register</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="2">&nbsp;</td>
                                        </tr>
                                        <tr>
                                        <br/>
                                            <td colspan="2"  style="padding-left:10px;"><p><strong>Dear Admin,</strong></p></td></tr>
                                            
                                            <tr>
                                            <td style="padding-left:10px;"><strong>Customer Name:<strong></td><td>' . $a . ' ' . $b . ' </td></tr>
                                              <tr>
                                            <td style="padding-left:10px;"><strong>Email ID:</strong></td><td>' . $c . ' </td>
                                                
                                        </tr>
                                         <tr>
                                            <td style="padding-left:10px;"><strong>Phone No:<strong></td><td>' . $e . ' </td>
                                                
                                        </tr>
                                      <tr>
                                            <td  colspan="2">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="2" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';



        $to2 = $from;


        sendgridmail($to2, $message2, $subject1, '', '');

        // header("location:" . WEB_ROOT . "myaccount/");
        //exit;
    } else {
        $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-warning"></i>Something went wrong.. Please try later..</span></div>';
    }
    return $res;
}

function forgotpassword($a, $b) {
    if ($a != '') {
        $ress = DB_QUERY("SELECT `cusid`,`emailverification`,`phonenoverification` FROM `customer` WHERE (`emailid`='" . $a . "')OR(`phoneno`='" . $a . "') ");
        if ($ress['cusid'] != '') {
            if ($ress['emailverification'] == '1') {
                mysql_query("UPDATE `customer` SET `forgottenreq`='1' WHERE `emailid`='" . $a . "'");

                $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i>Please check your mail to change your passsword.</div>';


                $active_email_url = WEB_ROOT . 'forgotpassword/' . base64_encode(base64_encode(base64_encode($ress['cusid'] * 222))) . '/';

                $sqladmin = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $ress['cusid'] . "'");


                $from = getprofile('recoveryemail', '1');
                $to = trim($a);
                // $to="itsolusenz1@gmail.com";
                $subject = "Forgot Password Link for Your Account-Nbaysmart";
                $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Forgotten Password Request</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $sqladmin['title'] . '.' . $sqladmin['firstname'] . ' ' . $sqladmin['lastname'] . ',<br/><br>'
                        . '<p style="text-indent:50px;">We have received forgotten password request from your side,If you made this request, Please click the button below to change your password.</p><br><button style="margin-left:150px;" class="button" type="submit" name="updatepassword" id="updatepassword" class="form-control"><i class="fa fa-pencil-square-o"></i> <a style="color:#ffffff;text-align:"center;" href="' . $active_email_url . '">Change Your Password</a></button><br><br><br><p><span style="color:#ff0000">* If you are not send the request, please secure your account.</span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';


                sendgridmail($to, $message, $subject, '', '');
            } else if ($ress['phonenoverification'] == '1') {
                mysql_query("UPDATE `customer` SET `forgottenreq`='1' WHERE `phoneno`='" . $a . "'");

                $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i>Please check your sms to change your passsword.</div>';
                $sqladmin = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $ress['cusid'] . "'");


                //$message ='Dear '.$ress['firstname'].', Your one time verification code for NBAYSMART is '.$otp.'. Thank you';
                $message = 'Dear ' . $sqladmin['title'] . '.' . $sqladmin['firstname'] . ' ' . $sqladmin['lastname'] . ',<br/><br>'
                        . 'We Send an email for Reset your Password ,If you are not giving that Request,Please secure your Account.';
                sendsms('NBAYSI', $message, $a, $b, '1');
            } else {
                $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span style="color:#FF0000;"><i class="icon fa fa-close"></i> Your account in Deactive mode... Please contact Administrator </span></div>';
            }
        } else {
            $res = "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button><i class='icon fa fa-close'></i> Given Email Or Phone Number  doesn't match with our Records.</div>";
        }
    }
    return $res;
}

function updatepassword($a, $b, $c) {
    if ($a != '') {

        ///$myquery=  mysql_fetch_array(mysql_query("SELECT `password` FROM `customer` WHERE `cusid`='".$c."'"));
        $resa = mysql_query("UPDATE `customer` SET `password`='" . trim($a) . "',`forgottenreq`='0' WHERE `cusid`='" . $c . "'");

        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('signup','18','Password Update','" . $_SESSION['FUID'] . "','" . $b . "','" . $c . "')");

        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Successfully Updated!<br><br>Please wait you will get redirected soon.</span></div>';
    } else {
        $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Password was Empty!</span></div>';
    }
    return $res;
}

function fusersignout() {
    DB("UPDATE `userloginhty` SET `checkouttime`='" . date('Y-m-d H:i:s') . "' WHERE `ulid`='" . $_SESSION['HID'] . "'");
    //header("location:" . WEB_ROOT);
    // exit;
}

function getcompanydetails($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `company` WHERE `comid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delcompanydetails($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('delete','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `company` WHERE `comid` ='" . $c . "' ");
        //$resa = mysql_query("UPDATE `category` SET `modeoperation`='3' WHERE `cid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Company deleted!</div>';
    return $res;
}
function delcompanyreview($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('delete','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `review` WHERE `rvid` ='" . $c . "' ");
        //$resa = mysql_query("UPDATE `category` SET `modeoperation`='3' WHERE `cid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Company review deleted!</div>';
    return $res;
}
function servicedetails($a, $b) {
    $ress = DB_QUERY("SELECT `comid` FROM `company` WHERE (`cusid`='" . trim($b) . "') AND `status`!='2'");
    if ($ress['comid'] != '') {
        $resa = mysql_query("UPDATE `company` SET `services`='" . trim($a) . "' WHERE `cusid`='" . $_SESSION['FUID'] . "'");
        $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Successfully Updated!</span></div>';
    }
    return $res;
}

function companydetails($check, $a, $g1, $b, $c, $d, $e, $a1, $b1, $f, $c1, $d1, $e1, $f1, $g, $h, $i, $j, $k, $l, $m, $n, $o, $p, $q, $r, $servicesimp, $category, $subcategory, $shop_id, $addid) {
//    echo $l;
//    echo $o;
//    echo $p;
//    echo $q;
    //echo $r;
    // echo $s;
    //  echo $t;
    // echo $u;
    //echo $v;
    // echo $w;
//echo $x;
//echo $y;
    $checkq = DB_QUERY("SELECT * FROM  `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
    $checkcom = DB_QUERY("SELECT * FROM  `company` WHERE `cusid`='" . $_SESSION['FUID'] . "'");
    $wallet_amount = $checkq['wallet_amount'];
    //$ress = getcompanydetails('comid', $k);
    //echo $check;
    //echo "500";
    $s = '';
    $result_wallet = $wallet_amount;
    if ($check == '1') {
        $result_wallet = $wallet_amount - 100;
        $usertype = 1;
        $date = date("Y/m/d H:i:s");
        //$expired='1';

        $s = "`expdate`=DATE_ADD('$date', INTERVAL 1 MONTH),`usertype`='" . $usertype . "'";
    }
    $ress = DB_QUERY("SELECT `comid` FROM `company` WHERE (`cusid`='" . trim($k) . "') AND `status`!='2'");
    //echo "SELECT `comid` FROM `company` WHERE (`cusid`='" . trim($k) . "') AND `status`!='2'";
    if ($ress['comid'] == '') {

        $resa = DB("INSERT INTO `company` (`companyname`,`companytype`,`image`,`banner`,`phonenumber`,`landlinenumber`,`doorno`,`streetaddress`,`address`,`country`,`state`,`districtname`,`postcode`,`email`,`website`,`aboutservices`,`ip`,`cusid`,`updated_type`,`updated_id`,`services`,`category`,`subcategory`,`usertype`,`comid`) VALUES ('" . trim($a) . "','" . trim($g1) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($a1) . "','" . trim($b1) . "','" . mysql_real_escape_string(trim($f)) . "','" . trim($c1) . "','" . trim($d1) . "','" . trim($e1) . "','" . trim($f1) . "','" . trim($g) . "','" . trim($h) . "','" . mysql_real_escape_string(trim($i)) . "','" . trim($j) . "','" . trim($k) . "','2','" . $_SESSION['FUID'] . "','" . $servicesimp . "','" . $category . "','" . $subcategory . "','2','" . $addid . "')");
        $insert_id = mysql_insert_id();
        // echo "INSERT INTO `hours` (`cusid`,`comid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`ip`)VALUES('" . $_SESSION['FUID'] . "','" . $insert_id . "','" . $l . "','" . $m . "','" . $n . "','" . $o . "','" . $p . "','" . $q. "','".$r."','".trim($j)."')";
        $resa = DB("INSERT INTO `hours` (`cusid`,`comid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`ip`)VALUES('" . $_SESSION['FUID'] . "','" . $insert_id . "'," . $r . "','" . $l . "','" . $m . "','" . $n . "','" . $o . "','" . $p . "','" . $q . "','" . trim($j) . "')");



//        $shop_id = 'NMSHOP' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//
        $resa = DB("UPDATE `company` SET `shopid`='$shop_id' WHERE `comid`='$insert_id'");
        $myres = mysql_query("SELECT `comid` FROM `company` WHERE `cusid`='" . $insert_id . "'");
        if ($myres['comid'] == '') {
            //DB("INSERT INTO `hours` (`cusid`,`comid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`ip`)VALUES('" . $k . "','" . $insert_id . "','" . $x . "" . ',' . "" . $y . "','" . $l . "" . ',' . "" . $m . "','" . $n . "" . ',' . "" . $o . "','" . $p . "" . ',' . "" . $q . "','" . $r . "" . ',' . "" . $s . "','" . $t . "" . ',' . "" . $u . "','" . $v . "" . ',' . "" . $w . "','" . $j . "')");
        }
        $wallet_amount = DB("UPDATE `company` SET $s WHERE `cusid`='" . $_SESSION['FUID'] . "'");
        $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$result_wallet' WHERE `cusid`='" . $_SESSION['FUID'] . "'");
        //echo "UPDATE `company` SET $s WHERE `cusid`='" . $_SESSION['FUID'] . "'";
        // echo "UPDATE `customer` SET `wallet_amount`='$result_wallet' WHERE `cusid`='" . $_SESSION['FUID'] . "'";
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('insert companydetails','2','Insert','" . $_SESSION['UID'] . "','" . $j . "','" . $insert_id . "')");

        $res = '<div class="alert alert-success alert-dismissible"><span><i class="icon fa fa-check"></i>Successfully Inserted!</span></div>';
    } else {
        $resa = mysql_query("UPDATE `company` SET `companyname`='" . trim($a) . "',`companytype`='" . trim($g1) . "',`image`='" . trim($b) . "',`banner`='" . trim($c) . "',`phonenumber`='" . trim($d) . "',`landlinenumber`='" . trim($e) . "',`address`='" . mysql_real_escape_string(trim($f)) . "',`email`='" . trim($g) . "',`website`='" . trim($h) . "',`aboutservices`='" . mysql_real_escape_string(trim($i)) . "',`ip`='" . trim($j) . "',`doorno`='" . trim($a1) . "',`streetaddress`='" . trim($b1) . "',`country`='" . trim($c1) . "',`state`='" . trim($d1) . "',`districtname`='" . trim($e1) . "',`postcode`='" . trim($f1) . "',`updated_type`='2',`updated_id`='" . $_SESSION['FUID'] . "',`services`='" . $servicesimp . "',`category`='" . $category . "',`subcategory`='" . $subcategory . "' WHERE `cusid`='" . $_SESSION['FUID'] . "'");

        $wallet_amount = DB("UPDATE `company` SET $s WHERE `cusid`='" . $_SESSION['FUID'] . "'");

       
        DB("UPDATE `hours` SET `sun`='" . $r . "',`mon`='" . $l . "',`tue`='" . $m . "',`wed`='" . $n . "',`thu`='" . $o . "',`fri`='" . $p . "',`sat`='" . $q . "',`ip`='" . trim($j) . "' WHERE `cusid`='" . $_SESSION['FUID'] . "'");

        $myres = mysql_fetch_array($resa);
        $companydetail = DB_QUERY("SELECT * FROM `company` where `cusid`='" . $_SESSION['FUID'] . "'");

        //$wallet_amount=DB("UPDATE `company` SET `expdate`=DATE_ADD('$date', INTERVAL 1 MONTH) WHERE `cusid`='" . $_SESSION['FUID'] . "'"); 

        $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$result_wallet' WHERE `cusid`='" . $_SESSION['FUID'] . "'");

        //echo "UPDATE `customer` SET `wallet_amount`='$result_wallet' WHERE `cusid`='" . $_SESSION['FUID'] . "'";
        //mysql_query("UPDATE `hours` SET `sun`='" . $x . "" . ',' . "" . $y . "',`mon`='" . $l . "" . ',' . "" . $m . "',`tue`='" . $n . "" . ',' . "" . $o . "',`wed`='" . $p . "" . ',' . "" . $q . "',`thu`='" . $r . "" . ',' . "" . $s . "',`fri`='" . $t . "" . ',' . "" . $u . "',`sat`='" . $v . "" . ',' . "" . $w . "',`ip`='" . $j . "' WHERE `cusid`='" . $k . "'");

        $htry = DB("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('companydetails update','3','Update','" . $_SESSION['FUID'] . "','" . $j . "','" . $a . "')");
        $res = '<div class="alert alert-success alert-dismissible"><span><i class="icon fa fa-check"></i> Successfully Updated!</span></div>';
    }
    return $res;
}

function profileupdate($a, $b, $c, $d, $e, $f, $g, $h, $i, $j, $k, $l, $m, $n, $o) {

    $resa = mysql_query("UPDATE `customer` SET `title`='" . trim($a) . "',`firstname`='" . trim($b) . "',`lastname`='" . trim($c) . "',`usertype`='" . trim($e) . "',`image`='" . trim($f) . "',`address2`='" . trim($g) . "',`doorno`='" . trim($h) . "',`address1`='" . trim($i) . "',`country`='" . trim($j) . "',`state`='" . trim($k) . "',`city`='" . trim($l) . "',`postcode`='" . trim($m) . "',`ip`='" . trim($n) . "' WHERE `cusid`='" . $_SESSION['FUID'] . "'");

    mysql_query("UPDATE `company` SET `usertype`='" . trim($e) . "' WHERE `cusid`='" . $_SESSION['FUID'] . "'");

    $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('profileupdate','3','Update','" . $_SESSION['FUID'] . "','" . $n . "','" . $i . "')");
    $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Successfully Updated!</span></div>';
    //return $res;
}

function getprofileupdate($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `cusid`='$b' AND `status`!='2'"));
    $res = $get[$a];
    return $res;
}

function gethours($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `hours` WHERE `cusid`='$b' "));
    $res = $get[$a];
    return $res;
}

function getmd5id($autoid, $code, $table, $uid) {
    $data = DB("SELECT * FROM `$table` WHERE `customerid`='" . $uid . "'");
    $id = '';
    while ($fdata = mysql_fetch_array($data)) {
        if (md5($fdata[$autoid]) == $code) {
            $id = $fdata[$autoid];
        }
    }
    return $id;
}

function getad($a, $b) {
    $data = DB_QUERY("SELECT * FROM `create_ads` WHERE `id`='" . $b . "'");
    return $data[$a];
}

function show_category($id) {
    $cat = DB("SELECT `cid`,`categoryname` FROM `category` WHERE `status`='1' ORDER BY `categoryname` ASC");
    if (mysql_num_rows($cat) > 0) {
        $ret_data = '<option value="">Please select category</option>';
        while ($fcat = mysql_fetch_array($cat)) {
            $selc = '';
            if ($fcat['cid'] == $id) {
                $selc = 'selected';
            }
            $ret_data .= '<option value="' . $fcat['cid'] . '" ' . $selc . '>' . $fcat['categoryname'] . '</option>';
        }
    } else {
        $ret_data = '<option value="">No Category available</option>';
    }
    return $ret_data;
}

function show_subcategory($id, $a) {
    $s = '';
    if ($a != '') {
        $s .= " AND FIND_IN_SET('" . $a . "',`category`)";
    }
    $cat = DB("SELECT `scid`,`subcategoryname` FROM `subcategory` WHERE `status`='1'$s ORDER BY `subcategoryname` ASC");
    if (mysql_num_rows($cat) > 0) {
        $ret_data = '<option value="">Please select subcategory</option>';
        while ($fcat = mysql_fetch_array($cat)) {
            $selc = '';
            if ($fcat['scid'] == $id) {
                $selc = 'selected';
            }
            $ret_data .= '<option value="' . $fcat['scid'] . '" ' . $selc . '>' . $fcat['subcategoryname'] . '</option>';
        }
    } else {
        $ret_data = '<option value="">No Subcategory available</option>';
    }
    return $ret_data;
}

function show_innercategory($id, $a, $b) {
    $s = '';
    if ($a != '') {
        $s .= " AND FIND_IN_SET('" . $a . "',`category`)";
    }
    if ($b != '') {
        $s .= " AND FIND_IN_SET('" . $b . "',`subcategory`)";
    }
    $cat = DB("SELECT `icid`,`innercategoryname` FROM `innercategory` WHERE `status`='1'$s ORDER BY `innercategoryname` ASC");
    if (mysql_num_rows($cat) > 0) {
        $ret_data = '<option value="">Please select innercategory</option>';
        while ($fcat = mysql_fetch_array($cat)) {
            $selc = '';
            if ($fcat['icid'] == $id) {
                $selc = 'selected';
            }
            $ret_data .= '<option value="' . $fcat['icid'] . '" ' . $selc . '>' . $fcat['innercategoryname'] . '</option>';
        }
    } else {
        $ret_data = '<option value="">No Innercategory available</option>';
    }
    return $ret_data;
}

function delad($a) {
    $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Adverting Mgmt','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $a . "')");
    //$get = mysql_query("UPDATE `create_ads` SET `status`='2' WHERE `id` ='" . $c . "' ");
    $get = mysql_query("DELETE FROM `create_ads` WHERE `id` ='" . $_SESSION['FUID'] . "' ");

    $resa = mysql_query("UPDATE `create_ads` SET `modeoperation`='3' WHERE `id`='$c'");
//    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-close"></i> Successfully Deleted!</h4><!--<a href="' . $sitename . 'master/addadvertising_type.htm">Try Again</a>--></div>';
//    return $res;
}

function addagent($a, $b, $c, $d, $e, $f, $g, $locationname, $h, $i, $ii, $j, $k, $password, $l, $m, $n, $q, $o, $p, $r) {



    if ($p == '') {

        $ress = DB_QUERY("SELECT `aid` FROM `agent` WHERE `aid`!='' AND (`emailid`='" . $k . "' OR `phoneno`='" . $l . "') ");
//echo "SELECT `aid` FROM `agent` WHERE `aid`!='' $s $ph";
        if ($ress['aid'] == '') {

            $resa = mysql_query("INSERT INTO `agent` (`title`,`firstname`,`lastname`,`doorno`,`streetname`,`address`,`district`,`location`,`state`,`country`,`postcode`,`description`,`emailid`,`password`,`phoneno`,`image`,`status`,`verified`,`ip`,`updated_by`,`agent_id`) 
VALUES ('" . $a . "','" . $b . "','" . $c . "','" . $d . "','" . $e . "','" . $f . "','" . $g . "','" . $locationname . "','" . $h . "','" . $i . "','" . $ii . "','" . $j . "','" . trim($k) . "','" . $password . "','" . $l . "','" . $m . "','" . $n . "','" . $q . "','" . $o . "','" . $_SESSION['UID'] . "','" . $r . "')");
            $insert_id = mysql_insert_id();
            //$resa = mysql_query("UPDATE `agent` SET `modeoperation`='2' WHERE `id`='$p'");
//            $agent_id = 'NMA' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//
//            $resa = mysql_query("UPDATE `agent` SET `agent_id`='$agent_id' WHERE `aid`='$insert_id'");
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Agent Mgmt','10','Insert','" . $_SESSION['UID'] . "','" . $o . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-warning"></i> We already have this Email or Phone!</h4></div>';
        }
    } else {
        $ress = DB_QUERY("SELECT `aid` FROM `agent` WHERE `aid`!='" . $p . "' AND (`emailid`='" . $k . "' OR `phoneno`='" . $l . "') ");
        if ($ress['aid'] == '') {

            $resa = mysql_query("UPDATE `agent` SET `title`='" . $a . "',`firstname`='" . $b . "',`lastname`='" . $c . "',`doorno`='" . $d . "',`streetname`='" . $e . "',	`address`='" . $f . "',	`district`='" . $g . "',`location`='" . $locationname . "',`state`='" . $h . "',`country`='" . $i . "',`postcode`='" . $ii . "',`description`='" . $j . "',`emailid`='" . trim($k) . "',`password`='" . $password . "',`phoneno`='" . $l . "',	`image`='" . $m . "',	`status`='" . $n . "',`verified`='" . $q . "',`ip`='" . $o . "',`updated_by`='" . $_SESSION['UID'] . "',`agent_id`='" . $r . "' WHERE `aid`='" . $p . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Agent Master','10','Update','" . $_SESSION['UID'] . "','" . $o . "','" . $p . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-warning"></i> We already have this Email or Phone!</h4></div>';
        }
    }

    return $res;
}

/* product enquiry form start */

function enquire($firstname, $email, $phonenumber, $comments, $supliermail, $userid, $adid, $customerid, $s) {
    mysql_query("INSERT INTO `product-enquiry` (`firstname`,`email`,`phonenumber`,`comments`,`user-id`,`adid`,`customerid`) VALUES ('" . $firstname . "','" . $email . "','" . $phonenumber . "','" . $comments . "','" . $userid . "','" . $adid . "','" . $customerid . "')");

    $checkenquiry = mysql_fetch_array(mysql_query("SELECT `id`,`adtitle`,`advertising_id` FROM `create_ads` WHERE `advertising_id`='" . $adid . "'"));
    $adsid = $checkenquiry['id'] * 776 + 5;
    $adlink = WEB_ROOT . 'viewad-' . preg_replace('/-{2,}/', '-',str_replace("@","",str_replace('&','and',str_replace(" ", "-",str_replace(",","",str_replace("%", "", strtolower(preg_replace('/[^A-Za-z0-9& \ -]/', "", $checkenquiry['adtitle'])))))))) . '/?view=' . $adsid . '/';
    $from = getprofile('recoveryemail', '1');
    $to = trim($email);
    // $to="itsolusenz1@gmail.com";
    $subject = "Thank For  Your Enquiry";
    $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Enquiry Mail</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $firstname . ',<br/><br>'
            . '<p style="text-indent:50px;">We thank you for your interest on <a href="' . $adlink . '" target="_blank">' . $checkenquiry['adtitle'] . ' (' . $checkenquiry['advertising_id'] . ') </a>,We will notify the person who posted this Advertisement about your enquiry.</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

    //$headers = "MIME-Version: 1.0 \n";
    //$headers .= "Content-type: text/html; charset=iso-8859-1\n";
    //$headers .= "From: " . $from . " \r\n ";
    //mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');
    //echo $message;
    // echo $to, $subject, $message, $headers;
    // exit();

    $active_email_url = WEB_ROOT . 'myaccount/';
    $from1 = getprofile('recoveryemail', '1');
    $to1 = trim($supliermail);
    // $to="itsolusenz1@gmail.com";
    $subject1 = "Enquiry For Your Advertisement";
    $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Enquiry for your advertisement</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
    Dear ' . getcustomer('firstname', getadvertis('customerid', $s)) . '    ' . getcustomer('lastname', getadvertis('customerid', $s)) . ',<br/><br>'
            . '<p style="text-indent:50px;">Your Advertisement <a href="' . $adlink . '" target="_blank">' . $checkenquiry['adtitle'] . ' (' . $checkenquiry['advertising_id'] . ') </a> had an Enquiry.for detailed information please log into your account at nbaysmart.com</p><br><br><br><p><span style="color:#ff0000"></span></p><span style="align:center;"><button style="margin-left:200px;" class="button" type="submit" name="updatepassword" id="updatepassword" class="form-control"><i class="fa fa-pencil-square-o"></i> <a style="color:#ffffff;text-align:"center;" href="' . $active_email_url . '" target="_blank">Click here to login</a></button></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers1 = "MIME-Version: 1.0 \n";
//    $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers1 .= "From: " . $from1 . " \r\n ";
//    mail($to1, $subject1, $message1, $headers1);
    sendgridmail($to1, $message1, $subject1, '', '');
    //echo $message1;
    // echo $to1, $subject1, $message1, $headers1;
    // exit();
$res='Message Successfully Sent';
return $res;
}

/* product enquiry form end */


/* company enquiry form start */

function companyenquire($firstname, $email, $phonenumber, $comments, $logcusid, $companyid, $ip) {
    mysql_query("INSERT INTO `company-enquiry` (`firstname`,`email`,`phonenumber`,`comments`,`logcusid`,`companyid`,`ip`) VALUES ('" . $firstname . "','" . $email . "','" . $phonenumber . "','" . $comments . "','" . $logcusid . "','" . $companyid . "','" . $ip . "')");

    $companyres = DB_QUERY("SELECT * FROM `company` WHERE `shopid`='" . $companyid . "'");

    $from = getprofile('recoveryemail', '1');
    $to = trim($email);
    // $to="itsolusenz1@gmail.com";
    $subject = "Thank You For Enquiry";
    $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Enquiry Mail</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $firstname . ',<br/><br>'
            . '<p style="text-indent:50px;">Greetings
            Thank you for Using Nbaysmart,  The enquiry you made to <b>' . $companyres['companyname'] . '</b> have been successfully received by them and they will soon contact you regarding your enquiry.  Nbaysmart support team is always online to assist you in every possible way.  You can always make more extensive searches in Nbaysmart to explore more business opportunity</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//    $headers = "MIME-Version: 1.0 \n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers .= "From: " . $from . " \r\n ";
//    mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');
    //echo $message;
    //echo $to, $subject, $message, $headers;
    //exit();


    $active_email_url = WEB_ROOT . 'myaccount/';

    $from1 = getprofile('recoveryemail', '1');
    $to1 = trim($companyres['email']);
    // $to="itsolusenz1@gmail.com";
    $subject1 = "Company Enquiry Report";
    $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Enquiry Report</span></td>
                                                        
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
    Dear ' . getcustomer('firstname', $companyres['cusid']) . '    ' . getcustomer('lastname', $companyres['cusid']) . ',<br/><br>'
            . '<p><b>' . $companyres['companyname'] . ',</b></p><br/>
                 <p style="text-indent:50px;">Your Business listing in Nbaysmart had an enquiry regarding a product or Service that you offer . To know more details regarding the enquiry, <b>log in  your Nbaysmart account and go to Pending Enquiry page to learn more about it.</b> We like to thank you for using Nbaysmart and you can always gain more business opportunity from our premium ads as they provide more exposure to your Ads and Listings.</p><br><br><br><p><span style="color:#ff0000"></span></p><span style="align:center;"><button style="margin-left:200px;" class="button" type="submit" name="updatepassword" id="updatepassword" class="form-control"><i class="fa fa-pencil-square-o"></i> <a style="color:#ffffff;text-align:"center;" href="' . $active_email_url . '" target="_blank">Click here to login</a></button></span>
                                            </td>
                                            
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';
    sendgridmail($to1, $message1, $subject1, '', '');
//    $headers1 = "MIME-Version: 1.0 \n";
//    $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//    $headers1 .= "From: " . $from1 . " \r\n ";
//    mail($to1, $subject1, $message1, $headers1);
    //echo $message1;
    //echo $to1, $subject1, $message1, $headers1;
    //exit();
}

/* company enquiry form end */

/* Review start */

function addreview($fu, $cu, $a, $b, $c, $d, $e, $f, $g) {
    if ($fu != '') {
        $rescheck = DB_QUERY("SELECT * FROM `review` WHERE `logcusid`='" . $fu . "' AND `cusid`='" . $cu . "'");
        if ($rescheck['logcusid'] == '') {
            $resa = mysql_query("INSERT INTO `review` (`logcusid`,`cusid`,`name`,`email`,`mobilenumber`,`rating`,`comments`,`ip`) VALUES ('" . trim($fu) . "','" . trim($cu) . "','" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','" . trim($f) . "')");

            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('companyreview','customer','Insert','" . $_SESSION['UID'] . "','" . $f . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-check"></i> We thank you for your valuable reviews. Your review will be posted in max 24 hours.</div>';

            $checkquery = mysql_fetch_array(mysql_query("SELECT * FROM `company` WHERE `shopid`='" . getreview('cusid', $insert_id) . "'"));
            if ($checkquery['comid'] != '') {
                $revid = $checkquery['shopid'];
                $email = $checkquery['email'];
                $cusid = $checkquery['cusid'];
                $name = $checkquery['companyname'];
            } else {
                $checkquery1 = mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `customer`='" . getreview('cusid', $insert_id) . "'"));
                $revid = $checkquery1['customerid'];
                $email = $checkquery1['emailid'];
                $cusid = $checkquery1['cusid'];
                $name = $checkquery1['firstname'] . ' ' . $checkquery1['lastname'];
            }
            $rev = $insert_id * 2611;
            $_SESSION['myrvid'] = $rev;

            $from = $email;
            $to = getcustomer('emailid', getreview('logcusid', $insert_id));
            // $to="itsolusenz1@gmail.com";
            $subject = "Thank You For Your Review";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Review</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                Dear ' . getcustomer('firstname', getreview('logcusid', $insert_id)) . ' ' . getcustomer('lastname', getreview('logcusid', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">We thank you for your valuable review for this company  <b>(' . $checkquery['companyname'] . '' . $checkquery['shopid'] . ') </b>. Your review will be posted after moderation.</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers = "MIME-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";
            //echo $message;
            //exit();
//            mail($to, $subject, $message, $headers);
            // echo $to,$subject,$message,$headers;
            // exit;
            //  sendgridmail($to, $message, $subject, '', '');



            $from1 = getprofile('recoveryemail', '1');
            // $from1 = getcomp('email', '6');
            $to1 = $email;
            // $to="itsolusenz1@gmail.com";
            $subject1 = " Company Review Posted";
            $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Review</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
                                            
    Dear ' . getcustomer('firstname', $cusid) . getcustomer('lastname', $cusid) . '<br/><br>'
                    . '<p style="text-indent:50px;">You have received a review for your company  <b>(' . $name . '-' . $revid . ')</b>, from ' . getcustomer('firstname', getreview('logcusid', $insert_id)) . ' ' . getcustomer('lastname', getreview('logcusid', $insert_id)) . '. please <a href="' . WEB_ROOT . 'company-review/' . $_SESSION['myrvid'] . '/' . $revid . '/">login</a> to your account on nbaysmart to learn more details about the review. </p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

            //  $headers1 = "MIME-Version: 1.0 \n";
            //  $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
            //   $headers1 .= "From: " . $from1 . " \r\n ";
            //echo $message1;
            //exit();
            //  mail($to1, $subject1, $message1, $headers1);
            sendgridmail($to1, $message1, $subject1, '', '');
            // echo $to1, $subject1, $message1, $headers1;
            // exit;
        } elseif ($rescheck['rvid'] != '') {
            $resa = mysql_query("UPDATE `review` SET `logcusid`='" . trim($fu) . "', `cusid`='" . trim($cu) . "', `name`='" . trim($a) . "',`email`='" . trim($b) . "',`mobilenumber`='" . trim($c) . "',`rating`='" . trim($d) . "',`comments`='" . trim($e) . "',`ip`='" . trim($f) . "',`status`='0' WHERE `rvid`='" . $rescheck['rvid'] . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('review','customer','Insert','" . $_SESSION['UID'] . "','" . $f . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-check"></i> We thank you for your valuable updated reviews. Your review will be posted in max 24 hours.</div>';

            $from = getcustomer('emailid', getreview('cusid', $rescheck['rvid']));
            $to = getcustomer('emailid', getreview('logcusid', $rescheck['rvid']));
            // $to="itsolusenz1@gmail.com";
            $subject = "Thank You For Your Review";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Review Update</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                Dear ' . getcustomer('firstname', getreview('logcusid', $insert_id)) . ' ' . getcustomer('lastname', getreview('logcusid', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">We thank you for your valuable updated review for our company  <b>' . $checkquery['companyname'] . '' . $checkquery['shopid'] . ' </b>. Your review will be posted after moderation.</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers = "MIME-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";
            //echo $message;
            //exit();
//            mail($to, $subject, $message, $headers);
            // echo $to,$subject,$message,$headers;
            // exit;
            sendgridmail($to, $message, $subject, '', '');



            $from1 = getprofile('recoveryemail', '1');
            // $from1 = getcomp('email', '6');
            $to1 = getcustomer('emailid', getreview('cusid', $rescheck['rvid']));
            // $to="itsolusenz1@gmail.com";
            $subject1 = " Company Review Posted";
            $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Review Update</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
                                            
    Dear ' . getcustomer('firstname', getreview('cusid', $insert_id)) . getcustomer('lastname', getreview('cusid', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">You have received a company review update for your company  <b>(' . $checkquery['companyname'] . '-' . $checkquery['shopid'] . ')</b>, from ' . getcustomer('firstname', getreview('logcusid', $insert_id)) . ' ' . getcustomer('lastname', getreview('logcusid', $insert_id)) . '. please <a href="' . WEB_ROOT . '">login</a> to your account on nbaysmart to learn more details about the review. </p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers1 = "MIME-Version: 1.0 \n";
//            $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers1 .= "From: " . $from1 . " \r\n ";
//echo $message1;
//exit();
            // mail($to1, $subject1, $message1, $headers1);
            sendgridmail($to1, $message1, $subject1, '', '');
            // echo $to1, $subject1, $message1, $headers1;
            //  exit;
        } else {
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Already Your Updated a Review for this company !</div>';
        }
    }
    return $res;
}

function getreview($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `review` WHERE `rvid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delreview($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('delete','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `review` WHERE `rvid` ='" . $c . "' ");
        //$resa = mysql_query("UPDATE `category` SET `modeoperation`='3' WHERE `cid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Review deleted!</div>';
    return $res;
}

/* Review end */

/* Products Review start */

function addproductreview($a, $b, $c, $d, $e, $f) {
    if ($c != '') {
        $rescheck = DB_QUERY("SELECT * FROM `productreview` WHERE `productid`='" . $b . "' AND `reviewby`='" . $c . "'");
        if ($rescheck['rpid'] == '') {
            $resa = mysql_query("INSERT INTO `productreview` SET `review`='$a', `productid`='$b', `reviewby`='$c',`supplier_id`='$d',`ip`='$e',`rating`='$f'");

            $insert_id = mysql_insert_id();
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('review','customer','Insert','" . $_SESSION['UID'] . "','" . $e . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-check"></i> We thank you for your valuable reviews. Your review will be posted within 24 hours.</div>';

            // . getcustomer('firstname',getadvertis('customerid',$id)) .

            $from = getprofile('recoveryemail', '1');
            $to = getcustomer('emailid', getproductreview('reviewby', $insert_id));
            // $to="itsolusenz1@gmail.com";
            $subject = "Thank You For Your Review";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Review</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                Dear ' . getcustomer('firstname', getproductreview('reviewby', $insert_id)) . ' ' . getcustomer('lastname', getproductreview('reviewby', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">We thank you for your valuable review for this product  <b>' . getadvertis('adtitle', getproductreview('productid', $insert_id)) . ' ( ' . getadvertis('advertising_id', getproductreview('productid', $insert_id)) . ' ) ' . ' </b>. Your review will be posted within 24 hours.</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers = "MIME-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";
            //echo $message;
            //exit();
            //mail($to, $subject, $message, $headers);
            //echo $to,$subject,$message,$headers;
            //exit;
            sendgridmail($to, $message, $subject, '', '');



            $from1 = getprofile('recoveryemail', '1');
            // $from1 = getcomp('email', '6');
            $to1 = getcustomer('emailid', getproductreview('supplier_id', $insert_id));
            // $to="itsolusenz1@gmail.com";
            $subject1 = " Product Review Posted";
            $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Review</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
    Dear ' . getcustomer('firstname', getproductreview('supplier_id', $insert_id)) . getcustomer('lastname', getproductreview('supplier_id', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">You have received a product review for your product  <b>' . getadvertis('adtitle', getproductreview('productid', $insert_id)) . ' ( ' . getadvertis('advertising_id', getproductreview('productid', $insert_id)) . ' ) ' . ' </b> please <a href="' . WEB_ROOT . '">login</a> to your account on nbaysmart for managing your reviews. </p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers1 = "MIME-Version: 1.0 \n";
//            $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers1 .= "From: " . $from1 . " \r\n ";
//echo $message1;
//exit();
            // mail($to1, $subject1, $message1, $headers1);
            sendgridmail($to1, $message1, $subject1, '', '');
            // echo $to1, $subject1, $message1, $headers1;
            //exit;
        } elseif ($rescheck['rpid'] != '') {
            $resa = mysql_query("UPDATE `productreview` SET `review`='$a', `productid`='$b', `reviewby`='$c',`supplier_id`='$d',`ip`='$e',`rating`='$f',`status`='0' WHERE `rpid`='" . $rescheck['rpid'] . "'");

            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('review','customer','Insert','" . $_SESSION['UID'] . "','" . $e . "','" . $insert_id . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-check"></i> We thank you for your valuable updated review. Your review will be posted in max 24 hours.</div>';

            $from = getprofile('recoveryemail', '1');
            $to = getcustomer('emailid', getproductreview('reviewby', $rescheck['rpid']));
            // $to="itsolusenz1@gmail.com";
            $subject = "Thank You For Your Review";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Review post</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                Dear ' . getcustomer('firstname', getproductreview('reviewby', $rescheck['rpid'])) . ' ' . getcustomer('lastname', getproductreview('reviewby', $rescheck['rpid'])) . '<br/><br>'
                    . '<p style="text-indent:50px;">We thank you for your valuable updated review for this product  <b>' . getadvertis('adtitle', getproductreview('productid', $rescheck['rpid'])) . ' ( ' . getadvertis('advertising_id', getproductreview('productid', $rescheck['rpid'])) . ' ) ' . ' </b>. Your review will be posted in max 24 hours.</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers = "MIME-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";
//            //echo $message;
//            //exit();
//            mail($to, $subject, $message, $headers);
            //echo $to,$subject,$message,$headers;
            //exit;
            sendgridmail($to, $message, $subject, '', '');



            $from1 = getprofile('recoveryemail', '1');
            // $from1 = getcomp('email', '6');
            $to1 = getcustomer('emailid', getproductreview('supplier_id', $rescheck['rpid']));
            // $to="itsolusenz1@gmail.com";
            $subject1 = " Product Review Updated";
            $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Review</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
    Dear ' . getcustomer('firstname', getproductreview('supplier_id', $insert_id)) . getcustomer('lastname', getproductreview('supplier_id', $insert_id)) . '<br/><br>'
                    . '<p style="text-indent:50px;">You have received a product update review for your product  <b>' . getadvertis('adtitle', getproductreview('productid', $insert_id)) . ' ( ' . getadvertis('advertising_id', getproductreview('productid', $insert_id)) . ' ) ' . ' </b> please <a href="' . WEB_ROOT . '">login</a> to your account on nbaysmart for managing your reviews. </p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

//            $headers1 = "MIME-Version: 1.0 \n";
//            $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers1 .= "From: " . $from1 . " \r\n ";
//echo $message1;
//exit();
            // mail($to1, $subject1, $message1, $headers1);
            sendgridmail($to1, $message1, $subject1, '', '');
            // echo $to1, $subject1, $message1, $headers1;
            //exit;
        } else {
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Already Your Updated a Review This Product !</div>';
        }
    }
    return $res;
}

function getproductreview($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `productreview` WHERE `rpid`='$b'"));
    $res = $get[$a];
    return $res;
}

function delproductreview($a) {
    $b = str_replace(".", ",", $a);
    $b = explode(",", $b);
    foreach ($b as $c) {
        $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('delete','1','Delete','" . $_SESSION['UID'] . "','" . $_SERVER['REMOTE_ADDR'] . "','" . $c . "')");
        $get = mysql_query("DELETE FROM `productreview` WHERE `rpid` ='" . $c . "' ");
        //$resa = mysql_query("UPDATE `category` SET `modeoperation`='3' WHERE `cid`='$c'");
    }
    $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><i class="icon fa fa-close"></i> Review deleted!</div>';
    return $res;
}

/* Products Review end */

function addcompany($cusid, $companytype, $usertype, $companyname, $phonenumber, $landlinenumber, $email, $website, $aboutservices, $companyimage, $img, $doorno, $Address1, $Address2, $country, $State, $districtname, $PostCode, $ip, $s, $status, $servicesimp, $category, $subcategoryname, $shop_id, $addid, $sun, $mon, $tue, $wed, $thu, $fri, $sat) {

    if ($s == '') {
        $resc = DB_QUERY("SELECT `comid` FROM `company` WHERE `cusid`='" . $cusid . "' AND `status`='1'");
        if ($resc['comid'] == '') {
            $resa = DB("INSERT INTO `company` (`cusid`,`usertype`,`companytype`,`companyname`,`doorno`,`streetaddress`,`address`,`country`,`state`,`districtname`,`postcode`,`phonenumber`,`landlinenumber`,`email`,`website`,`aboutservices`,`image`,`banner`,`ip`,`updated_id`,`updated_type`,`status`,`services`,`category`,`subcategory`,`shopid`,`comid`)VALUES('" . $cusid . "','" . $usertype . "','" . $companytype . "','" . $companyname . "','" . mysql_real_escape_string($doorno) . "','" . $Address1 . "','" . $Address2 . "','" . $country . "','" . $State . "','" . $districtname . "','" . $PostCode . "','" . $phonenumber . "','" . $landlinenumber . "','" . $email . "','" . mysql_real_escape_string($website) . "','" . mysql_real_escape_string($aboutservices) . "','" . $companyimage . "','" . $img . "','" . trim($ip) . "','" . $_SESSION['UID'] . "','2','" . trim($status) . "','" . $servicesimp . "','" . $category . "','" . $subcategoryname . "','" . $shop_id . "','" . $addid . "')");

            $insert_id = mysql_insert_id();
//            $shop_id = 'NMSHOP' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);
//            $resa = DB("UPDATE `company` SET `shopid`='$shop_id' WHERE `comid`='$insert_id'");
            $customerid = DB_QUERY("SELECT * FROM `company` WHERE `comid`='$insert_id'");
            $resw = DB("INSERT INTO `hours` (`cid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`cus_id`,`ip`)VALUES('" . $insert_id . "','" . $sun . "','" . $mon . "','" . $tue . "','" . $wed . "','" . $thu . "','" . $fri . "','" . $sat . "','" . $cusid . "','" . $ip . "')");
            $company = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='$cusid'");
            $date = date("Y/m/d H:i:s");
            $result_amount = $company['wallet_amount'];
            if ($usertype == 1) {
                $result_amount = $company['wallet_amount'] - 100;
            }

            $wallet_amount = DB("UPDATE `company` SET `expdate`=DATE_ADD('$date', INTERVAL 1 MONTH) WHERE `comid`='$insert_id' and `usertype`='1' ");
            $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$result_amount' WHERE `cusid`='" . $customerid['cusid'] . "' ");
            $htry = DB("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Company Master','12','Insert','" . $_SESSION['UID'] . "','" . $ip . "','" . $insert_id . "')");
            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i>Successfully Inserted!</h4></div>';
        } else {
            $res = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-close"></i>Company Already Exist!</h4></div>';
        }
    } else {
        $resc = DB_QUERY("SELECT `comid` FROM `company` WHERE `cusid`='" . $cusid . "' AND `comid`!='" . $s . "' AND `status`='1'");

        if ($resc['comid'] == '') {
            $resa = DB("UPDATE `company` SET `cusid`='$cusid',`companytype`='" . $companytype . "',`companyname`='" . $companyname . "',`streetaddress`='" . $Address1 . "',`address`='" . $Address2 . "',`doorno`='" . mysql_real_escape_string($doorno) . "',`country`='" . $country . "',`state`='" . $State . "',`districtname`='" . $districtname . "',`postcode`='" . $PostCode . "',`phonenumber`='" . $phonenumber . "',`landlinenumber`='" . $landlinenumber . "',`email`='" . $email . "',`website`='" . mysql_real_escape_string($website) . "',`aboutservices`='" . mysql_real_escape_string($aboutservices) . "',`banner`='" . $img . "',`image`='" . $companyimage . "',`ip`='" . trim($ip) . "',`updated_id`='" . $_SESSION['UID'] . "',`updated_type`='2',`status`='" . trim($status) . "',`services`='" . $servicesimp . "',`category`='" . $category . "',`subcategory`='" . $subcategoryname . "',`shopid`='" . $shop_id . "' WHERE `comid`='" . trim($s) . "'");

//            $shop_id = 'NMSHOP' . str_pad($s, 5, '0', STR_PAD_LEFT);
//
//            $resa = DB("UPDATE `company` SET `shopid`='$shop_id' WHERE `comid`='$s'");
            $customerid = DB_QUERY("SELECT * FROM `company` WHERE `comid`='$s'");
            $company = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='$cusid'");

            $l = '';
            $result_amount = $company['wallet_amount'];
            if ($usertype == 1) {
                $result_amount = $company['wallet_amount'] - 100;
                $date = date("Y/m/d H:i:s");
                $l = "`expdate`=DATE_ADD('$date', INTERVAL 1 MONTH),`usertype`='" . $usertype . "'";
            }

            if ($usertype == 1) {
                $wallet_amount = DB("UPDATE `company` SET $l WHERE `comid`='$s' ");
                //echo "UPDATE `company` SET $l WHERE `comid`='$s'";echo "500";
                $walletupdate = DB("UPDATE `customer` SET `wallet_amount`='$result_amount' WHERE `cusid`='" . $customerid['cusid'] . "' ");
            }
            $reswd = DB_QUERY("SELECT 'cid' FROM `hours` where `cid`='" . $s . "'");
            if ($reswd['cid'] == '') {
                $resw = DB("INSERT INTO `hours` (`cid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`cus_id`,`ip`)VALUES('" . $s . "','" . $sun . "','" . $mon . "','" . $tue . "','" . $wed . "','" . $thu . "','" . $fri . "','" . $sat . "','" . $cusid . "','" . $ip . "')");
            } else {
                $resw = DB("UPDATE `hours` SET `sun`='" . $sun . "',`mon`='" . $mon . "',`tue`='" . $tue . "',`wed`='" . $wed . "',`thu`='" . $thu . "',`fri`='" . $fri . "',`sat`='" . $sat . "',`ip`='" . $ip . "',`cus_id`='" . $cusid . "' WHERE `cid`='" . $s . "'");
            }
            $htry = mysql_query("INSERT INTO `history` (`page`,`pageid`,`action`,`userid`,`ip`,`actionid`) VALUES ('Company Master','12','Update','" . $_SESSION['UID'] . "','" . trim($ip) . "','" . trim($v) . "')");

            $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-check"></i> Successfully Updated!</h4></div>';
        } else {
            $res = '<div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">Ã—</button><h4><i class="icon fa fa-warning"></i> Company Already Exist!</h4></div>';
        }
    }


    return $res;
}

/* Advertisements start */

//a = type, b= limit, c= new/featured/top-trends
function advertisement($a, $b, $c, $d, $e, $f) {
    $type = $a;
    $limit = $b;
    $atype = $c;
    $fview =$f;
    $s = '';
    
    if ($d != '') {
        $s.=" AND `category` = '" . $d . "'";
    }
    if ($e != '') {
        $s.=" AND `subcategory` = '" . $e . "'";
    }

    if ($type == '1') {
        $sv.=" AND FIND_IN_SET('1',`companytype`)";
    } elseif ($type == '2') {
        $sv.=" AND FIND_IN_SET('2',`companytype`)";
    } elseif ($type == '3') {
        $s.=" AND `posttype`='0'";
    } elseif ($type == '4') {
        $s.=" AND `posttype`='1'";
    } elseif ($type == '5') {
        $s.=" AND `posttype`='3'";
    } elseif ($type == '6') {
        $s.=" AND `posttype`='2'";
    } else {
        $s.="";
    }

    $k = '';
    if ($atype == 'new') {
        $k.=" ORDER BY `id` DESC";
        $sk.=" ORDER BY `comid` DESC";
    } elseif ($atype == 'featured') {
        //$ress = DB_QUERY("SELECT `images`,`adtitle`,`customerid`,`advertising_id`,`id`,`posttype`,`adtype`,`link`,`originalprice`,`offerprice`,`producttype`,`availableqty`,`viewcount` FROM `create_ads` WHERE `admin_status`='1' AND `status`='1' AND `expired`='0'  LIMIT $limit");
        // $de = DB_QUERY("SELECT `cusid` FROM `company` WHERE `usertype`='1' ");
        //echo "SELECT `cusid` FROM `customer` WHERE `type`='1' ";
        //$k.=" AND (`adtype`='2' OR  '" . $de['cusid'] . "' ) ORDER BY RAND()";
        $k.=" AND (`adtype`='2') ORDER BY RAND()";
        $sk.=" AND (`usertype`='1') ORDER BY `comid` DESC";
    } elseif ($atype == 'top-trends') {
        $k.=" AND `viewcount`>0 ORDER BY `viewcount` DESC";
        $sk.=" AND `viewcount`>0 ORDER BY `viewcount` DESC";
    } else {
        $k.=" ORDER BY RAND()";
        $sk.=" ORDER BY RAND()";
    }
    $l='';
    if($fview=='home'){
       $l.="AND (`image`!='')"; 
       $ll.="AND (`images`!='')";
    }
   if ($_SESSION['location'] != '') {
        $locname.= " AND LOWER(`districtname`)='" . strtolower($_SESSION['location']) . "'";
        
   } else {
        $locname = "";
   }

    if ($sv != '') {
        $ress = "SELECT `comid`,`cusid`,`shopid`,`companyname`,`image`,`phonenumber`,`address`,`viewcount`,`districtname`,`state`,`usertype` FROM `company` WHERE `status`='1' $s $l $sk LIMIT $limit";
        $res = '';
        $ads = DB("SELECT `comid`,`cusid`,`shopid`,`companyname`,`image`,`phonenumber`,`address`,`viewcount`,`districtname`,`state`,`usertype` FROM `company` WHERE `status`='1' $locname $s $l $sk   LIMIT $limit");
     
        while ($fads = mysql_fetch_array($ads)) {
            $img = $fads['image'];
            $imgpath = $docroot . "logo/" . $img;
            $lowertitle=stripslashes(strtolower($fads['companyname']));
            $lowerlocation=stripslashes(strtolower($fads['districtname'].', '.$fads['state']));
            //echo $imgpath;
//            $adlink = WEB_ROOT . 'shops/' . $fads['districtname'] . '/' . $fads['companyname'] . '/' . $fads['shopid'] . '/' . base64_encode("" . md5($fads['shopid'])) . '/';
            
            $adlink = WEB_ROOT . 'company/' . str_replace(" ", "-", strtolower($fads['districtname'])) . '/' . preg_replace('/-{2,}/', '-',str_replace("@","",str_replace('&','and',str_replace(" ", "-",str_replace(",","",str_replace("%", "", strtolower(preg_replace('/[^A-Za-z0-9& \ -]/', "", $fads['companyname'])))))))) . '/?view=' . $fads['shopid'];
            $res.='<li style="border-radius:10px 10px;border-bottom: 5px solid #F91261;margin:10px;background-color:#fff;" class="hover-li" itemscope itemtype="http://schema.org/LocalBusiness"><table width="100%" height="400"><tbody><tr><td><div class="left-block"  itemscope itemtype="https://schema.org/Thing" >';
            if (($img != '') && (file_exists($imgpath))) {
                $res.='<a href="' . $adlink . '"><table width="100%" height="250"><tbody><tr><td align="center" valign="middle" width="100%"><img itemprop="image" class="img-responsive"  style=" max-height:250px;width:auto;border-radius: 10px 10px;margin: 0px;" alt="' . stripslashes($fads['companyname']) . '"    src="' . WEB_ROOT . 'logo/' . $img . '" /></td></tr></tbody></table></a>';
                 if($fads['usertype']==1){
                $res.='<span><img class="img-responsive" alt="product" style="position: absolute;bottom: 0px;left: 0px;width: 110px;height: auto;border-radius: 0px 10px 0px 0px;" src="'. WEB_ROOT .'images/premium.png" /></span>';
            }
            } else {
                $res.='<a href="' . $adlink . '"><table width="100%" height="250"><tbody><tr><td align="center" valign="middle" width="100%"><img itemprop="image" style=" max-height:250px;width:auto;border-radius: 10px 10px;margin: 0px;" class="img-responsive"   alt="' . stripslashes($fads['companyname']) . '" src="' . WEB_ROOT . 'images/noimage.jpg" /></td></tr></tbody></table></a>';
            }
            if($fads['usertype']==1){
                $res.='<span><img class="img-responsive" alt="product" style="position: absolute;bottom: 0px;left: 0px;width: 110px;height: auto;border-radius: 0px 10px 0px 0px;" src="'. WEB_ROOT .'images/premium.png" /></span>';
            }
            $res.='
                </div>
                <hr style="margin-bottom:0px;margin-top:5px;">
		<div class="right-block" style="margin-top:15px;max-height: 150px;" itemscope itemtype="https://schema.org/Thing" >
                <h3 class="product-name ad-title"><a href="' . $adlink . '" ><span itemprop="name">' . substr(stripslashes($lowertitle), 0, 60);
            if (strlen($lowertitle) > 60) {
                $res.= '..';
            }
            $res.='</span></a></h3>
                <hr style="margin-bottom:0px;margin-top:1px;">
                 <i class="fa fa-map-marker i-class"><span itemscope itemtype="http://schema.org/PostalAddress" class="ad-location"><itemprop="addressLocality"> ' . substr(stripslashes($lowerlocation),0,20) .'';
            if (strlen($lowerlocation) > 20) {
                $res.= '..';
            }
            $res.='</itemprop></span></i>
					</div>
                                        </td></tr></tbody></table>
				</li>';
        }
    } else {
        $ress = "SELECT `images`,`adtitle`,`customerid`,`advertising_id`,`id`,`posttype`,`adtype`,`link`,`originalprice`,`offerprice`,`producttype`,`availableqty`,`viewcount` FROM `create_ads` WHERE `admin_status`='1' AND `status`='1' AND `expired`='0'  $s $k LIMIT $limit";

        $res = '';

        $ads = DB("SELECT `images`,`adtitle`,`advertising_id`,`id`,`posttype`,`adtype`,`link`,`originalprice`,`offerprice`,`producttype`,`availableqty`,`viewcount`,`districtname`,`state` FROM `create_ads`  WHERE `admin_status`='1' AND `status`='1' AND `expired`='0' $locname $ll $s $k LIMIT $limit");
   //echo "SELECT `images`,`adtitle`,`advertising_id`,`id`,`posttype`,`adtype`,`link`,`originalprice`,`offerprice`,`producttype`,`availableqty`,`viewcount`,`districtname`,`state` FROM `create_ads`  WHERE `admin_status`='1' AND `status`='1' AND `expired`='0' $locname $ll $s $k LIMIT $limit";
        // echo "SELECT `a`.`images`,`a`.`adtitle`,`a`.`advertising_id`,`a`.`id`,`a`.`posttype`,`a`.`adtype`,`a`.`link`,`a`.`originalprice`,`a`.`offerprice`,`a`.`producttype`,`a`.`availableqty`,`a`.`viewcount`,`b`.* FROM `create_ads` as `a` ,`customer` as `b`  WHERE `a`.`admin_status`='1' AND `b`.`city`='".$_SESSION['location']."' AND `b`.`cusid`=`a`.`customerid` AND `a`.`status`='1' AND `a`.`expired`='0' $s $k LIMIT $limit";
        while ($fads = mysql_fetch_array($ads)) {
            $img = explode(",", $fads['images']);
            $imgpath = $docroot . "adm/" . $img[0];
            $adsid = $fads['id'] * 776 + 5;
            $lowertitle=stripslashes(strtolower($fads['adtitle']));
            $lowerlocation=stripslashes(strtolower($fads['districtname'].', '.$fads['state']));

            //$adlink = WEB_ROOT . 'advid-' . $adsid . '/' . $fads['advertising_id'] . '/' . $fads['adtitle'] . '/';
          
            $adlink = WEB_ROOT . 'viewad-' . preg_replace('/-{2,}/', '-',str_replace("@","",str_replace('&','and',str_replace(" ", "-",str_replace(",","",str_replace("%", "", strtolower(preg_replace('/[^A-Za-z0-9& \ -]/', "", $fads['adtitle'])))))))) . '/' . '?view=' . $adsid . '/';

            if (($fads['posttype'] == '0') || ($fads['posttype'] == '1')) {
                $sctype = 'itemscope itemtype="https://schema.org/Product"';
                $pcond = '<span style="display:none; margin:0; padding:0;" itemprop="itemCondition">' . $ptype . '</span>';
                $pidd = '<span style="display:none; margin:0; padding:0;" itemprop="productID">' . stripslashes($fads['advertising_id']) . '</span>';
            } /* else {
              $sctype = 'itemscope itemtype="https://schema.org/Service"';
              $pidd = '';
              $pcond = '';
              } */
            if ($fads['producttype'] == '1') {
                $ptype = 'New';
            } elseif ($fads['producttype'] == '2') {
                $ptype = 'Old';
            } else {
                $ptype = '';
            }
            $res.='<li ' . $sctype . ' style="border-radius:10px 10px;border-bottom: 5px solid #F91261;margin:10px;background-color:#fff;" class="hover-li">
                <a title="'.$lowertitle.'" href="' . $adlink . '" itemprop="url">
                <span style="display:none; margin:0; padding:0;" itemprop="Category">' . getcategory('categoryname', $fads['category']) . '</span>
                ' . $pcond . '
                ' . $pidd . '
                     <table width="100%" height="400"><tbody><tr><td>
                <div class="left-block">';
            if (($img[0] != '') && (file_exists($imgpath))) {
                $res.='<a href="' . $adlink . '"><table width="100%" height="250"><tbody><tr><td align="center" valign="middle" width="100%"><img itemprop="image" style=" max-height:250px;width:auto;border-radius: 10px 10px;margin: 0px;" class="img-responsive" alt="' . stripslashes($fads['adtitle']) . '"  src="' . WEB_ROOT . 'adm/' . $img[0] . '" />';
                 if ($fads['originalprice'] != 0 || $fads['originalprice'] != '') {
                $res.='<span style="background:rgba(0,0,0,0.5);color:#fff;float:right;padding:10px;position: absolute;bottom:0px;right:0px;" itemprop="priceCurrency" content="INR"><i class="fa fa-inr"></i><itemprop="price" content="' . number_format($fads['originalprice'], '0', '.', ',') . '"> ' . number_format($fads['originalprice'], '0', '.', ',') . '</itemprop></span>';
            }
             if($fads['adtype']==2){
                $res.='<span><img class="img-responsive" alt="product" style="position: absolute;bottom: 0px;left: 0px;width: 110px;height: auto;border-radius: 0px 10px 0px 0px;" src="'. WEB_ROOT .'images/premium.png" /></span>';
            }
                $res.='</td></tr></tbody></table></a>'; 
               
            } else {
                $res.='<a href="' . $adlink . '"><table width="100%" height="250"><tbody><tr><td align="center" valign="middle" width="100%"><img itemprop="image" style=" max-height:250px;width:auto;border-radius: 10px 10px;margin: 0px;" class="img-responsive"  alt="' . stripslashes($fads['adtitle']) . '" src="' . WEB_ROOT . 'images/noimage.jpg" />';
                if ($fads['originalprice'] != 0 || $fads['originalprice'] != '') {
                $res.='<span style="background:rgba(0,0,0,0.5);color:#fff;float:right;padding:10px;position: absolute;bottom:0px;right:0px;" itemprop="priceCurrency" content="INR"><i class="fa fa-inr"></i><itemprop="price" content="' . number_format($fads['originalprice'], '0', '.', ',') . '"> ' . number_format($fads['originalprice'], '0', '.', ',') . '</itemprop></span>';
            }
            if($fads['adtype']==2){
                $res.='<span><img class="img-responsive" alt="product" style="position: absolute;bottom: 0px;left: 0px;width: 110px;height: auto;border-radius: 0px 10px 0px 0px;" src="'. WEB_ROOT .'images/premium.png" /></span>';
            }
                $res.='</td></tr></tbody></table></a>'; 
            }
            $res.='</div>
                 <hr style="margin-bottom:0px;margin-top:5px;">
                <div class="right-block" style="margin-top:15px;max-height: 150px;">
                    <h3 class="product-name ad-title" itemprop="name"><a href="' . $adlink . '">' . substr(stripslashes($lowertitle), 0, 60) . '</a>';
            if (strlen($lowertitle) > 60) {
                $res.= '..';
            } $res.='</h3>
                 <hr style="margin-bottom:0px;margin-top:1px;">
                  <i class="fa fa-map-marker i-class"><span class="ad-location">'.substr(stripslashes($lowerlocation), 0, 20).'';
            if (strlen($lowerlocation) > 20) {
                $res.= '..';
            }
            $res.='</span></i>';
           
//            if ($fads['originalprice'] > 0) {
//                if ($fads['offerprice'] > 0) {
//                    $res.='<span class="price product-price" itemprop="priceCurrency" content="INR"><i class="fa fa-inr"></i> <itemprop="offerprice" content="' . number_format($fads['offerprice'], '0', '.', ',') . '">' . number_format($fads['offerprice'], '0', '.', ',') . '</itemprop></span><span class="price old-price"><i class="fa fa-inr"></i> <itemprop="price" content="' . number_format($fads['originalprice'], '0', '.', ',') . '">' . number_format($fads['originalprice'], '0', '.', ',') . '</itemprop></span>';
//                } else {
//                    $res.='<span class="price product-price" itemprop="priceCurrency" content="INR"><i class="fa fa-inr"></i><itemprop="price" content="' . number_format($fads['originalprice'], '0', '.', ',') . '"> ' . number_format($fads['originalprice'], '0', '.', ',') . '</itemprop></span>';
//                }
//            }
            $res.='</div></td></tr></tbody></table>';
//            $discount = (100) - ( $fads['offerprice'] / $fads['originalprice'] * 100);
//            if (($fads['offerprice'] > 0) && ($discount > 1)) {
//                $res.='<div class="price-percent-reduction2"> SAVE ' . number_format($discount, '0', '.', ',') . '% </div>';
//            }
            $res.='</a></li>';
        }
    }
    return $res;
}
/* Advertisements end */

function addenq($a, $b, $c, $n, $p, $d, $com, $ip, $logcusid, $companyid, $comments, $rep, $re) {
    $resa = mysql_query("INSERT INTO `company-enquiry`  (`firstname`,`date`,`email`,`to1`,`subject`,`replaycomment`,`ip`,`logcusid`,`companyid`,`comments`,`replay`,`read1`,`phonenumber`)  VALUES ('" . $n . "','" . date('Y-m-d H:i:s') . "','" . $com . "','" . $a . "','" . $b . "','" . $c . "','" . $ip . "','" . $logcusid . "','" . $companyid . "','" . $comments . "','" . $rep . "','" . $re . "','" . $p . "')");



    $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><span><i class="icon fa fa-check"></i> Your comments successfully submitted .</span></div>';


    $up2 = DB_QUERY("SELECT * FROM `company-enquiry` WHERE `ceid`='" . $d . "' ");
    if ($up2['replay'] != '1') {
        DB("UPDATE `company-enquiry` SET `replay` ='1' WHERE `ceid`='" . $d . "' ");
//echo "UPDATE `company-enquiry` SET `replay` ='1' WHERE `ceid`='" . $d . "'";
//exit(0);
    }

    $sqladmin = DB_QUERY("SELECT * FROM `manageprofile` WHERE `pid`='1'");

    $from = getprofile('recoveryemail', '1');
    $to = trim($a);
    $subject = trim($b);

    $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Enquiry Mail Reply</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Dear ' . $n . '<br/><br>'
            . '<p style="text-indent:50px;">' . trim($c) . '</p><br><br><br><p><span style="color:#ff0000"></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; <br />All Rights Reserved.&nbsp;<br/></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

    //  $headers = "MIME-Version: 1.0 \n";
    //  $headers .= "Content-type: text/html; charset=iso-8859-1\n";
    // $headers .= "From: " .  $from . " \r\n ";
    // mail($to, $subject, $message, $headers);
    sendgridmail($to, $message, $subject, '', '');

//echo $to, $subject, $message, $headers;
//exit;



    $sqladmin1 = DB_QUERY("SELECT * FROM `customer` WHERE `cusid`='" . $_SESSION['FUID'] . "'");


    $from1 = getprofile('recoveryemail', '1');
    $to1 = trim($sqladmin1['emailid']);

    $subject1 = "Enquiry mail report ";
    $message1 = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Enquiry mail report</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;"> 
    Dear  ' . $sqladmin1['title'] . '.' . $sqladmin1['firstname'] . ' ' . $sqladmin1['lastname'] . ' <br/><br>'
            . '<p style="text-indent:50px;">Your mail has been sent successfully.</p><br><br><br><p><span style="color:#ff0000"></span></p><span style="align:center;"></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; <br />All Rights Reserved.&nbsp;<br/></td>
                                            
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

    // $headers1 = "MIME-Version: 1.0 \n";
    // $headers1 .= "Content-type: text/html; charset=iso-8859-1\n";
//$headers1 .= "From: " . $from1 . " \r\n ";
    //mail($to1, $subject1, $message1, $headers1);
    sendgridmail($to1, $message1, $subject1, '', '');

//echo $to1, $subject1, $message1, $headers1;
//exit;



    return $res;
}

function getenq($a, $b) {
    $get = mysql_fetch_array(mysql_query("SELECT * FROM `company-enquiry` WHERE `ceid`='$b'"));
    $res = $get[$a];
    return $res;
}

function hourdetails($sun, $mon, $tue, $wed, $thu, $fri, $sat, $ip) {
    $company = DB_QUERY("SELECT * FROM `company` where `cusid`='" . $_SESSION['FUID'] . "'");
    $tim = DB_QUERY("SELECT * FROM `hours` WHERE  `cus_id`='" . $_SESSION['FUID'] . "' and `cid`='" . $company['comid'] . "'");
    if ($tim == '') {
        DB("INSERT INTO `hours` (`cid`,`sun`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`cus_id`,`ip`)VALUES('" . $company['comid'] . "','" . $sun . "','" . $mon . "','" . $tue . "','" . $wed . "','" . $thu . "','" . $fri . "','" . $sat . "','" . $_SESSION['FUID'] . "','" . $ip . "')");

        //admin Sms End	
        $res = '<div class="alert alert-success alert-dismissible"><span><i class="icon fa fa-check"></i>Successfully Inserted!</span></div>';
    } else {
        DB("UPDATE `hours` SET `sun`='" . $sun . "',`mon`='" . $mon . "',`tue`='" . $tue . "',`wed`='" . $wed . "',`thu`='" . $thu . "',`fri`='" . $fri . "',`sat`='" . $sat . "',`ip`='" . $ip . "' WHERE `cid`='" . $company['comid'] . "'");
        $res = '<div class="alert alert-success alert-dismissible"><span><i class="icon fa fa-check"></i> Successfully Updated!</span></div>';
    }
    return $res;
}

/* reset password start */

function resetpassword($a, $b) {
    if ($a != '') {
        $checkmail = DB_QUERY("SELECT `cusid`,`emailid` FROM `customer` WHERE `cusid` !='" . $_SESSION['FUID'] . "' AND `emailid`='".$a."'");
        //echo "SELECT `cusid`,`emailid` FROM `customer` WHERE `cusid` !='" . $_SESSION['FUID'] . "' AND `emailid`='".$a."'";
        //exit;
        if ($checkmail['emailid'] ==''){
            $num = '';
            for ($i = 0; $i < 6; $i++)
                $num .= mt_rand(0, 9);
            $resetkey = $num;
          mysql_query("UPDATE `customer` SET `resetpassword`='" . $resetkey . "' WHERE `emailid`='" . $a . "' AND `cusid`='" . $_SESSION['FUID'] . "'");
        //  echo "UPDATE `customer` SET `resetpassword`='".$resetkey."' WHERE `emailid`='" . $a . "' AND `cusid`='".$_SESSION['FUID']."'";
        // exit;
          
            $active_email_url = WEB_ROOT . 'resetpassword/step1/';
            $selcustomer=mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `emailid`='".$a."'"));
            $from = getprofile('recoveryemail', '1');
            $to = trim($a);
            // $to="itsolusenz1@gmail.com";
            $subject = "Reset Password Link for Your Account-Nbaysmart";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Request to reset password</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Hi ' . $selcustomer['title'] . '.' . $selcustomer['firstname'] . ' ' . $selcustomer['lastname'] . ',<br/><br>' . '<p style="text-indent:50px;">We have received request from you to reset your password,If you made this request, Please click the button below to reset your password.</p><br><p>Paste your reset password code : '.$selcustomer['resetpassword'].'</p><br><button style="margin-left:150px;" class="button" type="submit" name="resetpassword" id="resetpassword" class="form-control"><i class="fa fa-pencil-square-o"></i> <a style="color:#ffffff;text-align:"center;" target="_blank" href="' . $active_email_url . '">Reset your password</a></button><br><br><br><br><br><p><span style="color:#ff0000">* If your not making a reset password request, please secure your account.</span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';
//            $headers = "MIE-Version: 1.0 \n";
//            $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//            $headers .= "From: " . $from . " \r\n ";       
//            mail($to, $subject, $message, $headers);            
//            echo $to, $subject, $message, $headers;
//            exit;

            sendgridmail($to, $message, $subject, '', '');
              $res = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i> Please check your mail to reset your passsword. wait to enter your verification code</div>';
              echo '<META http-equiv="refresh" content="5;URL=' . WEB_ROOT . 'resetpassword/step1/">';
        } else {
            $res = "<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button><i class='icon fa fa-close'></i> Email address already exists, please enter valid email address.</div>";
        }
    }
    return $res;
}

/* reset password end */

/*final reset password start */
function fusersignupverifyad($a, $b, $c, $d, $e,$Address,$Address1,$districtname,$state,$country,$postcode) {
    if ($b != '') {
        $v = 'email';
        $ress = DB_QUERY("SELECT `cusid`,`emailid`,`phoneno`,`emailverification` FROM `customer` WHERE `emailid`='" . $b . "'");
        if ($ress['cusid'] != '') {
            if (($ress['emailverification'] == 0) && ($ress['emailid'] != '')) {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/notverified/");
                exit;
            } elseif ($ress['emailid'] != '') {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/exist/");
                exit;
            }
        }
    } elseif ($c != '') {
        $v = 'mobile';
        $ress = DB_QUERY("SELECT `cusid`,`phoneno`,`emailid`,`phonenoverification` FROM `customer` WHERE `phoneno`='" . $c . "'");
        if ($ress['cusid'] != '') {
            if (($ress['phonenoverification'] == 0) && ($ress['phoneno'] != '')) {
                $_SESSION['regtype'] = $v;
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/notverified/");
                exit;
            } elseif ($ress['phoneno'] != '') {
                $_SESSION['VUID'] = $ress['cusid'];
                header("location:" . WEB_ROOT . "signup/exist/");
                exit;
            }
        }
    }
    if ($ress['cusid'] == '') {
        $num = '';
        for ($i = 0; $i < 6; $i++)
            $num .= mt_rand(0, 9);
        $otp = $num;

        $resa = mysql_query("INSERT INTO `customer` (`firstname`,`emailid`,`phoneno`,`password`,`ip`,`status`,`updatedtype`,`otp`,`signupwith`,`address2`,`address1`,`city`,`state`,`country`,`postcode`,`usertype`) VALUES ('" . trim($a) . "','" . trim($b) . "','" . trim($c) . "','" . trim($d) . "','" . trim($e) . "','0','1','" . trim($otp) . "','" . $v . "','".trim($Address)."','".trim($Address1)."','".trim($districtname)."','".trim($state)."','".trim($country)."','".trim($postcode)."','1')");


        $insert_id = mysql_insert_id();

        $customer_id = 'NMC' . str_pad($insert_id, 5, '0', STR_PAD_LEFT);

        $resa = mysql_query("UPDATE `customer` SET `customerid`='" . $customer_id . "' WHERE `cusid`='" . $insert_id . "'");

        $_SESSION['CUSID'] = $insert_id;
        $_SESSION['regtype'] = $v;

        if ($b != '') {
            $_SESSION['VUID'] = $insert_id;
            verificationmail($b, $otp, $_SESSION['VUID']);
            //header("location:" . WEB_ROOT . "signup/step2/");
            //exit;
        } elseif ($c != '') {
            $message = 'Hi ' . $a . ', Your one time verification code for NBAYSMART is ' . $otp . '. Thank you';
            sendsms('NBAYSI', $message, $c, $e, '1');
            $_SESSION['VUID'] = $insert_id;
            //header("location:" . WEB_ROOT . "signup/step2/");
            //exit;
        }
    }

    return $res;
}

function finalresetpassword($a, $b,$c) {
    if($_SESSION['FUID']!=''){
    if (($a != '')&&($b!='')) {
        if(trim($a)!=getcustomer('password',$_SESSION['FUID']))
        {
        
            mysql_query("UPDATE `customer` SET `password`='".trim($a)."',`resetpassword`='' WHERE `cusid`='".$_SESSION['FUID']."'");
         
            $active_email_url = WEB_ROOT . 'my_dashboard/';
            $selcustomer=mysql_fetch_array(mysql_query("SELECT * FROM `customer` WHERE `cusid`='".$_SESSION['FUID']."'"));
            $from = getprofile('recoveryemail', '1');
            $to = trim($selcustomer['emailid']);
            // $to="itsolusenz1@gmail.com";
            $subject = "Password changed your account-Nbaysmart";
            $message = '
                    <table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Password changed</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                Hi ' . $selcustomer['title'] . '.' . $selcustomer['firstname'] . ' ' . $selcustomer['lastname'] . ',<br/><br>' . '<p style="text-indent:50px;">Your password has been changed successfully.please login to access your account by clicking below button.</p><br><button style="margin-left:150px;" class="button" type="submit" name="resetpassword" id="resetpassword" class="form-control"><i class="fa fa-pencil-square-o"></i> <a style="color:#ffffff;text-align:"center;" target="_blank" href="' . $active_email_url . '">Login</a></button><br><br><p style="text-align:center;">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';
//                $headers = "MIE-Version: 1.0 \n";
//                $headers .= "Content-type: text/html; charset=iso-8859-1\n";
//                $headers .= "From: " . $from . " \r\n ";       
//                mail($to, $subject, $message, $headers);            
//                echo $to, $subject, $message, $headers;
//                exit;

            sendgridmail($to, $message, $subject, '', '');
               $messagecode = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-check"></i> Your password has been changed, please to redirect.</div>';
                   $_SESSION['verificationcode']='';
        echo '<META http-equiv="refresh" content="2;URL=' . WEB_ROOT . 'my_dashboard/">';
        }else{
             $messagecode = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-close"></i> Dont use your old password, please use different combination.</div>';
        }
    }else{
        $messagecode = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button><i class="icon fa fa-close"></i> please enter valid link to reset your password.</div>';
    }
    }
    return $messagecode;
}

/* final reset password end */
function featuremailsend($a,$b,$c,$d) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    if($c!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($c);
    $subject = "Expire Feature Company - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your featured company</p>
                                                <p>Company Name: ' . $a . '</p>
                                                <p>Shop Id: ' . $b . '</p>
                                                <p>is about to expired in today.Please Renew your Feature status to Receive more Enquiries.</p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your featured company, Your Company Name : ' . $a . ', Shop Id :' . $b . 'is about to expired in today.Please Renew your Feature status to Receive more Enquiries.  Thank you';
                    
                    sendsms('NBAYSI', $message, $d, $ip, '1');  
}
}
function featurbeforeemailsend($a,$b,$c,$d) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
    if($c!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($c);
    $subject = "Expire Feature Company - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Company Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your featured company</p>
                                                <p>Company Name: ' . $a . '</p>
                                                <p>Shop Id: ' . $b . '</p>
                                                <p>is about to expired in 7 days.Please Renew your Feature status to Receive more Enquiries.</p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your featured company, Your Company Name : ' . $a . ', Shop Id :' . $b . 'is about to expire in 7 days.Please Renew your Feature status to Receive more Enquiries.  Thank you';
                    
                    sendsms('NBAYSI', $message, $d, $ip, '1');  
}
}
function featureadmailsend($a,$b,$c) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
   
    $adcus=DB_QUERY("SELECT * FROM `customer` where `cusid`='".$c."' ");
    if($adcus['emailid']!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($adcus['emailid']);
    $subject = "Expire Feature Advertisement  - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your featured Advertisement</p>
                                                <p>Title: ' . $a . '</p>
                                                <p>Advertisement Id: ' . $b . '</p>
                                                <p>is about to expire in today.Please Renew your Feature status to Receive more Enquiries.</p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your featured Adverisement, Your Adtitle : ' . $a . ', Advertisement Id :' . $b . 'is about to expire in todays days.Please Renew your Feature status to Receive more Enquiries.Thank you';
                    
                    sendsms('NBAYSI', $message, $adcus['phoneno'], $ip, '1');  
}
}
function featureadmailsend1($a,$b,$c) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
   
    $adcus=DB_QUERY("SELECT * FROM `customer` where `cusid`='".$c."' ");
    if($adcus['emailid']!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($adcus['emailid']);
    $subject = "Expire Feature Advertisement  - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your featured Advertisement</p>
                                                <p>Title: ' . $a . '</p>
                                                <p>Advertisement Id: ' . $b . '</p>
                                                <p>is about to expire in today.</p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your featured Adverisement, Your Adtitle : ' . $a . ', Advertisement Id :' . $b . 'is about to expire in today.  Thank you';
                    
                    sendsms('NBAYSI', $message, $adcus['phoneno'], $ip, '1');  
}
}
function freeadmailsend($a,$b,$c) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
   
    $adcus=DB_QUERY("SELECT * FROM `customer` where `cusid`='".$c."' ");
    if($adcus['emailid']!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($adcus['emailid']);
    $subject = "Advertisement Expire to extend another 30 days  - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your  Advertisement posted on Nbaysmart is about to expire.Advertisement details,</p>
                                                <p>Title: ' . $a . '</p>
                                                <p>Advertisement Id: ' . $b . '</p>
                                                <p>We would like to Inform you that we are going to extend your Advertisement duration to another 30 days.If the Product is sold,please remove your advertisement from your account. </p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your Adverisement posted on nbaysmart is about to expire, Your Adtitle : ' . $a . ', Advertisement Id :' . $b . '.we are going to extend your advertisement duration to another 30 days.  Thank you';
                    
                    sendsms('NBAYSI', $message, $adcus['phoneno'], $ip, '1');  
}
}
function featurebeforeadmailsend($a,$b,$c) {
    //$active_email_url = WEB_ROOT . 'emailverification/' . base64_encode($s) . '/' . md5($s) . '/';
   
    $adcus=DB_QUERY("SELECT * FROM `customer` where `cusid`='".$c."' ");
    if($adcus['emailid']!=''){
    $from = getprofile('recoveryemail', '1');
    $to = trim($adcus['emailid']);
    $subject = "Expire Feature Advertisement  - Nbaysmart";
    $message = '<table width="100%" height="100%" style="background:#FFFFF;">
                            <tr>
                                <td align="center" valign="middle">
                                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="border:10px solid #F91261; background:#f3f3f3; font-family:sans-serif; font-size:12px;">
                                        <tr>
                                            <td align="left" valign="top" colspan="3">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
                                                    <tr>
                                                        <td width="50%" align="center" valign="top" bgcolor="#FFFFFF">
                                                            <img src="' . WEB_ROOT . 'images/logo3.png" border="0" height="70" /> 
                                                        </td>
                                                        <td width="50%" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Helvetica, sans-serif; color:#000000; font-weight:bold; font-size:15px;">&nbsp;&nbsp;&nbsp;<span style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000000; font-weight:bold;">Advertisement Details</span></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" valign="top" colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="padding:10px;">
                                                <p><strong>Dear Customer,</strong></p>
                                                <p>Thank you for using Nbaysmart,your featured Advertisement</p>
                                                <p>Title: ' . $a . '</p>
                                                <p>Advertisement Id: ' . $b . '</p>
                                                <p>is about to expire in 7 days.Please Renew your Feature status to Receive more Enquiries.</p>
                                                <p>&nbsp;</p>
                                                
                                                
                                                <p>Thank You</p>
                                                <p>&nbsp;</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="26"  colspan="3" align="center" valign="middle" bgcolor="#FFFFFF" style="font-family:Arial, Gadget, sans-serif; font-size:10px; color:#000; align:center; font-weight:normal;">Copyrights 2016 &copy; ' . $_SERVER['SERVER_NAME'] . '<br />All Rights Reserved.&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>';

  // echo $to,$message,$subject;
    sendgridmail($to, $message, $subject, '', '');
}
else{
    $ip = $_SERVER['REMOTE_ADDR'];
   $message = 'Hi ,Thank you for using Nbaysmart,your featured Adverisement, Your Adtitle : ' . $a . ', Advertisement Id :' . $b . 'is about to expire in 7 days.Please Renew your Feature status to Receive more Enquiries.  Thank you';
                    
                    sendsms('NBAYSI', $message, $adcus['phoneno'], $ip, '1');  
}
}

?>